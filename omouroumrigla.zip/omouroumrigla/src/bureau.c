#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "bureau.h"
#include <gtk/gtk.h>



    enum{
    EIDBR,
    EIDAG,
    ESEXE,
    EROLE,
    EVILLE,
    EECOLE,
    ECAPELEC,
    ECAPOB,
    ENSALLE,
    COLUMNS
 
};




void ajouter_br( bureau b )
{
    FILE * f=fopen("bureau.txt", "a");
    if(f!=NULL)
    {
        fprintf(f,"%s %s %s %s %s %s %s %s %d\n",b.id_br,b.id_agent,b.sexe,b.role,b.ville,b.ecole,b.cap_elec,
        b.cap_obs,b.n_salle);
        fclose(f);
        
    }
    
}


void supprimer_br( char idb[])
{
    
    bureau b;
    FILE * f=fopen("bureau.txt", "r");
    FILE * f2=fopen("nouv.txt", "a");
    
    while(fscanf(f,"%s %s %s %s %s %s %s %s %d\n",b.id_br,b.id_agent,b.sexe,b.role,b.ville,b.ecole,b.cap_elec,
        b.cap_obs,&b.n_salle)!=EOF)
        {
            if(strcmp(b.id_br,idb)!=0)
              {  
               fprintf(f2,"%s %s %s %s %s %s %s %s %d\n",b.id_br,b.id_agent,b.sexe,b.role,b.ville,b.ecole,b.cap_elec,
        b.cap_obs,b.n_salle);
        }
    }
    fclose(f);
    fclose(f2);
    remove("bureau.txt");
    rename("nouv.txt", "bureau.txt");
   
}


void modifier_bureau(bureau b1 )
{
bureau b ;
FILE * f=fopen ("bureau.txt","r");
FILE * f2=fopen("nouv.txt","a");
while(fscanf(f,"%s %s %s %s %s %s %s %s %d\n",b.id_br,b.id_agent,b.sexe,b.role,b.ville,b.ecole,b.cap_elec,b.cap_obs,&b.n_salle)!=EOF){
        if(strcmp(b.id_br,b1.id_br)==0){
                   b=b1;}
		
	fprintf(f2,"%s %s %s %s %s %s %s %s %d\n",b.id_br,b.id_agent,b.sexe,b.role,b.ville,b.ecole,b.cap_elec,
        b.cap_obs,b.n_salle);
    	}
fclose(f);
fclose(f2);
remove("bureau.txt");
rename("nouv.txt","bureau.txt");
}






void afficher_bureau(GtkWidget *liste){
          GtkCellRenderer *renderer;
          GtkTreeViewColumn *column;
          GtkTreeIter iter;
          GtkListStore *store;
          char id_br[30];
          char id_agent[30];
          char sexe[30];
          char role[30];
          char ville[30];
          char ecole [30];
          char cap_elec[30];
          char cap_obs[30];
          int n_salle;
          store=NULL;
          FILE *f;
          store=gtk_tree_view_get_model(liste);
          
          if(store==NULL){

          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("ID bureau de vote",renderer,"text",EIDBR,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

 
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("ID Agent bureau de vote",renderer,"text",EIDAG,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

 
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("le sexe de l'agent",renderer,"text",ESEXE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

 
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("Le role de l'agent",renderer,"text",EROLE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("Ville",renderer,"text",EVILLE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
     
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("Municipalite",renderer,"text",EECOLE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("La capacité des électeurs",renderer,"text",ECAPELEC,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("La capacité des observateurs",renderer,"text",ECAPOB,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("Le nombre des salles",renderer,"text",ENSALLE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
                 }

         store=gtk_list_store_new(COLUMNS, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT);

         f=fopen("bureau.txt","r");
         if(f==NULL){
         
            return;

         }
         else
         {
            f=fopen("bureau.txt","a+");
            while(fscanf(f,"%s %s %s %s %s %s %s %s %d\n",id_br,id_agent,sexe,role,ville,ecole,cap_elec,cap_obs,&n_salle)!=EOF)
            {    
                gtk_list_store_append(store,&iter);
                gtk_list_store_set(store,&iter,EIDBR,id_br,EIDAG,id_agent,ESEXE,sexe,EROLE,role,EVILLE,ville,EECOLE,ecole,ECAPELEC,cap_elec,ECAPOB,cap_obs,ENSALLE,n_salle, -1);


            }  
            fclose(f);
            gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
            g_object_unref(store);


}
}







void viderbr(GtkWidget *liste){
          GtkCellRenderer *renderer;
          GtkTreeViewColumn *column;
          GtkTreeIter iter;
          GtkListStore *store;
          char id_br[30];
          char id_agent[30];
          char sexe[30];
          char role[30];
          char ville[30];
          char ecole [30];
          char cap_elec[30];
          char cap_obs[30];
          int n_salle;
          store=NULL;
          FILE *f;
          store=gtk_tree_view_get_model(liste);
          
          if(store==NULL){

          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("ID bureau de vote",renderer,"text",EIDBR,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

 
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("ID Agent bureau de vote",renderer,"text",EIDAG,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

 
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("le sexe de l'agent",renderer,"text",ESEXE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

 
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("Le role de l'agent",renderer,"text",EROLE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("Ville",renderer,"text",EVILLE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
     
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("Municipalite",renderer,"text",EECOLE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("La capacité des électeurs",renderer,"text",ECAPELEC,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("La capacité des observateurs",renderer,"text",ECAPOB,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("Le nombre des salles",renderer,"text",ENSALLE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
}

         store=gtk_list_store_new(COLUMNS, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT);
         gtk_list_store_append(store,&iter);
          gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));

         
    //g_object_unref(store);


}

void rechercher_bureau(GtkWidget *liste,char rechbr[]){
     

          GtkCellRenderer *renderer;
          GtkTreeViewColumn *column;
          GtkTreeIter iter;
          GtkListStore *store;
          char id_br[30];
          char id_agent[30];
          char sexe[30];
          char role[30];
          char ville[30];
          char ecole [30];
          char cap_elec[30];
          char cap_obs[30];
          int n_salle;
          store=NULL;
          FILE *f;
          store=gtk_tree_view_get_model(liste);
          if(store==NULL){

          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("ID bureau de vote",renderer,"text",EIDBR,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

 
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("ID Agent bureau de vote",renderer,"text",EIDAG,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

 
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("le sexe de l'agent",renderer,"text",ESEXE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

 
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("Le role de l'agent",renderer,"text",EROLE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("Ville",renderer,"text",EVILLE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
     
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("Municipalite",renderer,"text",EECOLE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("La capacité des électeurs",renderer,"text",ECAPELEC,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("La capacité des observateurs",renderer,"text",ECAPOB,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("Le nombre des salles",renderer,"text",ENSALLE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

         store=gtk_list_store_new(COLUMNS, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT);
         f=fopen("bureau.txt","r");
         if(f==NULL){
         
            return;

         }
         else
         {
            f=fopen("bureau.txt","r");
            while(fscanf(f,"%s %s %s %s %s %s %s %s %d\n",id_br,id_agent,sexe,role,ville,ecole,cap_elec,cap_obs,&n_salle)!=EOF)
            {
               if(strcmp(rechbr,id_br)==0 || strcmp(rechbr,"")==0){
               gtk_list_store_append(store,&iter);
               gtk_list_store_set(store,&iter,EIDBR,id_br,EIDAG,id_agent,ESEXE,sexe,EROLE,role,EVILLE,ville,EECOLE,ecole,ECAPELEC,cap_elec,ECAPOB,cap_obs,ENSALLE,n_salle, -1);}


            }
            fclose(f);
            
            gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
            g_object_unref(store);

}
}
}




///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////newyesmine////////////////////////////////////////
int test_capelec(char cap_elec[]){
	int i;
        if(strcmp(cap_elec,"100==>1000")==0)
		i=0;
	else if (strcmp(cap_elec,"1000==>5000")==0)
		i=1;
else if (strcmp(cap_elec,"5000==>10000")==0)
		i=2;
	return i;
}

int test_capob(char cap_obs[]){
	int j;
        if(strcmp(cap_obs,"100==>1000")==0)
		j=0;
	else if (strcmp(cap_obs,"1000==>5000")==0)
		j=1;
else if (strcmp(cap_obs,"5000==>10000")==0)
		j=2;
	return j;
}


int test_ville(char ville[]){
	int k;
        if(strcmp(ville,"Tunis")==0)
		k=0;
	else if (strcmp(ville,"Sfax")==0)
		k=1;
else if (strcmp(ville,"Mahdia")==0)
		k=2;
	return k;
}


int test_ecole(char ecole[]){
	int l;
        if(strcmp(ecole,"BenArous")==0)
		l=0;
	else if (strcmp(ecole,"Ariana")==0)
		l=1;
else if (strcmp(ecole,"Zelba")==0)
		l=2;
else if (strcmp(ecole,"Kasba")==0)
		l=3;
else if (strcmp(ecole,"SfaxSud")==0)
		l=4;

	return l;
}

bureau find_br(char id[]){
    bureau b;
    FILE *f;
    f = fopen("bureau.txt","r");
    if(f != NULL){
	while(fscanf(f,"%s %s %s %s %s %s %s %s %d\n",b.id_br,b.id_agent,b.sexe,b.role,b.ville,b.ecole,b.cap_elec,b.cap_obs,&b.n_salle) != EOF)
        {
		if(strcmp(b.id_br,id) == 0)
	        {
       			return b;
                }
       }
     }
   
    fclose(f);
} 




///////////////////////////////verification idbr
int verifier_idbr(char id_br[]){
     bureau b;
 FILE *f1;
    f1 = fopen("bureau.txt","r");
    while(fscanf(f1,"%s %s %s %s %s %s %s %s %d\n",b.id_br,b.id_agent,b.sexe,b.role,b.ville,b.ecole,b.cap_elec,
        b.cap_obs,&b.n_salle) != EOF){
        if(strcmp(b.id_br,id_br)==0){	                 
	return 1;
        }
    }
    fclose(f1);
	return 0;
}


///////////////////////////

void supprimer_bureau(bureau b)
{  
     char id_br[30];
     char id_agent[30];
     char sexe[30];
     char role[30];
     char ville[30];
     char ecole [30];
     char cap_elec[30];
     char cap_obs[30];
     int n_salle;
     FILE*f,*g;
     f=fopen("bureau.txt","r");
     g=fopen("dmp.txt","w");
     if(f==NULL||g==NULL)
	{
               return;


        }
     else{
            while(fscanf(f,"%s %s %s %s %s %s %s %s %d\n",id_br,id_agent,sexe,role,ville,ecole,cap_elec,
        cap_obs,&n_salle) != EOF){
               if(strcmp(b.id_br,id_br)!=0||strcmp(b.id_agent,id_agent)!=0||strcmp(b.sexe,sexe)||strcmp(b.role,role)||strcmp(b.ville,ville)||strcmp(b.ecole,ecole)||strcmp(b.cap_elec,cap_elec)||strcmp(b.cap_obs,cap_obs)||b.n_salle==n_salle)
                     fprintf(g,"%s %s %s %s %s %s %s %s %d\n",id_br,id_agent,sexe,role,ville,ecole,cap_elec,cap_obs,n_salle);


                                      }

                         fclose(f);
                         fclose(g);
                      remove("bureau.txt");
                      rename("dmp.txt","bureau.txt");
         }



}


///////////////////////////////////finduser
/*user find_ag(char id[]){
    bureau b;
    user u;
    FILE *f,*f1;
    f = fopen("bureau.txt","r");
    f1=fopen("utilisateur.txt","r");
    if(f != NULL){
	while(fscanf(f1,"%s %s %s %s %d/%d/%d %s %s %s %s %s %s\n",u.cin,u.nom,u.prenom,u.id_bureau,&u.dateN.jour,&u.dateN.mois,&u.dateN.annee,u.email,u.tel,u.role,u.sexe,u.vote,u.password) != EOF)
        {

             
		if(strcmp(id,u.id_bureau) == 0)
	        {
       			return u;}
           
       }
     }
   
    fclose(f);
    fclose(f1);
} 
*/


void rechercher_tunis_yes(GtkWidget *liste){
     

          GtkCellRenderer *renderer;
          GtkTreeViewColumn *column;
          GtkTreeIter iter;
          GtkListStore *store;
          char id_br[30];
          char id_agent[30];
          char sexe[30];
          char role[30];
          char ville[30];
          char ecole [30];
          char cap_elec[30];
          char cap_obs[30];
          int n_salle;
          store=NULL;
          FILE *f;
          store=gtk_tree_view_get_model(liste);
          if(store==NULL){

          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("ID bureau de vote",renderer,"text",EIDBR,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

 
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("ID Agent bureau de vote",renderer,"text",EIDAG,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

 
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("le sexe de l'agent",renderer,"text",ESEXE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

 
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("Le role de l'agent",renderer,"text",EROLE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("Ville",renderer,"text",EVILLE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
     
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("Municipalite",renderer,"text",EECOLE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("La capacité des électeurs",renderer,"text",ECAPELEC,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("La capacité des observateurs",renderer,"text",ECAPOB,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("Le nombre des salles",renderer,"text",ENSALLE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

         store=gtk_list_store_new(COLUMNS, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT);
         f=fopen("bureau.txt","r");
         if(f==NULL){
         
            return;

         }
         else
         {
            f=fopen("bureau.txt","r");
            while(fscanf(f,"%s %s %s %s %s %s %s %s %d\n",id_br,id_agent,sexe,role,ville,ecole,cap_elec,cap_obs,&n_salle)!=EOF)
            {
               if(strcmp(ville,"Tunis")==0 ){
               gtk_list_store_append(store,&iter);
               gtk_list_store_set(store,&iter,EIDBR,id_br,EIDAG,id_agent,ESEXE,sexe,EROLE,role,EVILLE,ville,EECOLE,ecole,ECAPELEC,cap_elec,ECAPOB,cap_obs,ENSALLE,n_salle, -1);}


            }
            fclose(f);
            
            gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
            g_object_unref(store);

}
}
}


////////////////////////////////////////////////////////////////////////////////////////////////////////
void rechercher_mahdia_yes(GtkWidget *liste){
     

          GtkCellRenderer *renderer;
          GtkTreeViewColumn *column;
          GtkTreeIter iter;
          GtkListStore *store;
          char id_br[30];
          char id_agent[30];
          char sexe[30];
          char role[30];
          char ville[30];
          char ecole [30];
          char cap_elec[30];
          char cap_obs[30];
          int n_salle;
          store=NULL;
          FILE *f;
          store=gtk_tree_view_get_model(liste);
          if(store==NULL){

          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("ID bureau de vote",renderer,"text",EIDBR,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

 
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("ID Agent bureau de vote",renderer,"text",EIDAG,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

 
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("le sexe de l'agent",renderer,"text",ESEXE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

 
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("Le role de l'agent",renderer,"text",EROLE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("Ville",renderer,"text",EVILLE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
     
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("Municipalite",renderer,"text",EECOLE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("La capacité des électeurs",renderer,"text",ECAPELEC,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("La capacité des observateurs",renderer,"text",ECAPOB,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("Le nombre des salles",renderer,"text",ENSALLE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

         store=gtk_list_store_new(COLUMNS, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT);
         f=fopen("bureau.txt","r");
         if(f==NULL){
         
            return;

         }
         else
         {
            f=fopen("bureau.txt","r");
            while(fscanf(f,"%s %s %s %s %s %s %s %s %d\n",id_br,id_agent,sexe,role,ville,ecole,cap_elec,cap_obs,&n_salle)!=EOF)
            {
               if(strcmp(ville,"Mahdia")==0 ){
               gtk_list_store_append(store,&iter);
               gtk_list_store_set(store,&iter,EIDBR,id_br,EIDAG,id_agent,ESEXE,sexe,EROLE,role,EVILLE,ville,EECOLE,ecole,ECAPELEC,cap_elec,ECAPOB,cap_obs,ENSALLE,n_salle, -1);}


            }
            fclose(f);
            
            gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
            g_object_unref(store);

}
}
}
////////////////////////////////////////////////////////////////////////
void rechercher_sfax_yes(GtkWidget *liste){
     

          GtkCellRenderer *renderer;
          GtkTreeViewColumn *column;
          GtkTreeIter iter;
          GtkListStore *store;
          char id_br[30];
          char id_agent[30];
          char sexe[30];
          char role[30];
          char ville[30];
          char ecole [30];
          char cap_elec[30];
          char cap_obs[30];
          int n_salle;
          store=NULL;
          FILE *f;
          store=gtk_tree_view_get_model(liste);
          if(store==NULL){

          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("ID bureau de vote",renderer,"text",EIDBR,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

 
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("ID Agent bureau de vote",renderer,"text",EIDAG,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

 
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("le sexe de l'agent",renderer,"text",ESEXE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

 
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("Le role de l'agent",renderer,"text",EROLE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("Municipalite",renderer,"text",EVILLE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
     
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("Ecole",renderer,"text",EECOLE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("La capacité des électeurs",renderer,"text",ECAPELEC,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("La capacité des observateurs",renderer,"text",ECAPOB,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
          renderer=gtk_cell_renderer_text_new();
          column=gtk_tree_view_column_new_with_attributes("Le nombre des salles",renderer,"text",ENSALLE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

         store=gtk_list_store_new(COLUMNS, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT);
         f=fopen("bureau.txt","r");
         if(f==NULL){
         
            return;

         }
         else
         {
            f=fopen("bureau.txt","r");
            while(fscanf(f,"%s %s %s %s %s %s %s %s %d\n",id_br,id_agent,sexe,role,ville,ecole,cap_elec,cap_obs,&n_salle)!=EOF)
            {
               if(strcmp(ville,"Sfax")==0 ){
               gtk_list_store_append(store,&iter);
               gtk_list_store_set(store,&iter,EIDBR,id_br,EIDAG,id_agent,ESEXE,sexe,EROLE,role,EVILLE,ville,EECOLE,ecole,ECAPELEC,cap_elec,ECAPOB,cap_obs,ENSALLE,n_salle, -1);}


            }
            fclose(f);
            
            gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
            g_object_unref(store);

}
}
}






























