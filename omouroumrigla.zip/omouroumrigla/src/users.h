#include <stdio.h>
#include<gtk/gtk.h>
typedef struct
{
int jour;
int mois;
int annee;
}date1;

typedef struct
{char cin[20];
char nom[20];
char prenom[20];
char password[30];
date1 dateN;
char email[50];
char tel[20];
char role[20];
 char sexe[20];
char  id_bureau[20];
char vote[20];
}user;
void ajouter_user(user u);
user find_user(char id[]);
void genererPassword(char password[]);
int test_role(char role[]);
void rechercher_user(GtkWidget *liste,char rech[]);
float ageMoy(int year);
int nbrBureau(char id[]);
user find_ag(char id[]);
void TPHF(float *f, float *h);
float TPE(char *filename);
user update_user(char id[]);
