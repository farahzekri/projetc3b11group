#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

//#include <gtk/gtk.h>

#include "callbacks.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include "interface.h"
#include "support.h"
#include "users.c"
#include "bureau.h"
#include "election.h"
#include "observateur.h"
#include "liste.c"
int type=2;
char idM[80];
//user ust;
void
on_homme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active (GTK_RADIO_BUTTON(togglebutton)))
	type=1;
}


void
on_femme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active (GTK_RADIO_BUTTON(togglebutton)))
	type=2;
}

void
on_ajouterUser_clicked                 (GtkWidget       *button,
                                        gpointer         user_data)
{
	GtkWidget *cin, *nom, *prenom, *sexe, *id_bureau, *jour, *mois, *annee, *email, *tel, *role ,*id_bureau_err,*tel_err,*cin_err,*email_err,*nom_err,*prenom_err,*role_err;

char sexa[20];
char password[20];
GtkWidget *fenetre_ajout;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1; 
cin = lookup_widget (button, "cina");
nom = lookup_widget (button, "noma");
prenom = lookup_widget (button, "prenoma");
id_bureau = lookup_widget (button, "id_bureaua");
jour = lookup_widget (button, "joura");
mois = lookup_widget (button, "moisa");
annee = lookup_widget (button, "anneea");
email = lookup_widget (button, "emaila");
tel = lookup_widget (button, "tela");
role = lookup_widget (button, "rolea");
tel_err = lookup_widget (button, "tel_err");
id_bureau_err = lookup_widget (button, "id_bureau_err");
cin_err = lookup_widget (button, "cin_err");
email_err = lookup_widget (button, "email_err");
nom_err = lookup_widget (button, "nom_err");
prenom_err = lookup_widget (button, "prenom_err");
role_err = lookup_widget (button, "role_err");
genererPassword(password);
user u;


if (type== 1){
			strcpy(u.sexe,"homme");
		}
else if(type== 2){
			strcpy(u.sexe,"femme");
		}
date1 d;
//u.dateN=d
int test12=0;
strcpy(u.cin, gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(u.vote,"🆕" );
strcpy(u.nom, gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(u.prenom, gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(u.id_bureau, gtk_entry_get_text(GTK_ENTRY(id_bureau)));
strcpy(u.email, gtk_entry_get_text(GTK_ENTRY(email)));
strcpy(u.tel, gtk_entry_get_text(GTK_ENTRY(tel)));
strcpy(u.role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(role)));
d.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
d.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
d.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
strcpy(u.password,password);
u.dateN=d;
//
if (strlen(u.cin)!=8)
{
GdkColor color;

    gdk_color_parse ("red", &color);


    gtk_widget_modify_fg (cin_err, GTK_STATE_NORMAL, &color);
gtk_label_set_text(GTK_LABEL(cin_err),"Vérifier CIN !");
test12 =1;

}else if (verifier_CIN(u.cin)==1)
{
GdkColor color;

    gdk_color_parse ("red", &color);


    gtk_widget_modify_fg (cin_err, GTK_STATE_NORMAL, &color);
gtk_label_set_text(GTK_LABEL(cin_err),"CIN  deja existant !");
test12 =1;

}else
gtk_label_set_text(GTK_LABEL(cin_err),"");
//
if(strlen(u.tel)!=8){
  GdkColor color;

    gdk_color_parse ("red", &color);


    gtk_widget_modify_fg (tel_err, GTK_STATE_NORMAL, &color);
gtk_label_set_text(GTK_LABEL(tel_err),"Verifier le numéro de téléphone !");
test12 =1;

}else
gtk_label_set_text(GTK_LABEL(tel_err),"");
//
 if (strlen(u.id_bureau)!=7)
{
GdkColor color;

    gdk_color_parse ("red", &color);

    gtk_widget_modify_fg (id_bureau_err, GTK_STATE_NORMAL, &color);
gtk_label_set_text(GTK_LABEL(id_bureau_err),"Vérifier id_bureau !");
test12 =1;

}else
gtk_label_set_text(GTK_LABEL(id_bureau_err),"");
//
if (strlen(u.email)==0)
{
GdkColor color;

    gdk_color_parse ("red", &color);


    gtk_widget_modify_fg (email_err, GTK_STATE_NORMAL, &color);
gtk_label_set_text(GTK_LABEL(email_err),"Vérifier Email !");
test12 =1;

}else
gtk_label_set_text(GTK_LABEL(email_err),"");
/////
if(strlen(u.nom)==0){
  GdkColor color;

    gdk_color_parse ("red", &color);


    gtk_widget_modify_fg (nom_err, GTK_STATE_NORMAL, &color);
gtk_label_set_text(GTK_LABEL(nom_err),"Verifier le nom !");
test12 =1;

}else
gtk_label_set_text(GTK_LABEL(nom_err),"");
//
if(strlen(u.prenom)==0){
  GdkColor color;

    gdk_color_parse ("red", &color);


    gtk_widget_modify_fg (prenom_err, GTK_STATE_NORMAL, &color);
gtk_label_set_text(GTK_LABEL(prenom_err),"Verifier le prenom !");
test12 =1;

}else
gtk_label_set_text(GTK_LABEL(prenom_err),"");
//
if(strlen(u.role)==0){
  GdkColor color;

    gdk_color_parse ("red", &color);


    gtk_widget_modify_fg (role_err, GTK_STATE_NORMAL, &color);
gtk_label_set_text(GTK_LABEL(role_err),"Verifier le role !");
test12 =1;

}else
gtk_label_set_text(GTK_LABEL(role_err),"");
//
if (test12==0){
ajouter_user(u);
fenetre_ajout=lookup_widget(button,"ajouter");
gtk_widget_destroy(fenetre_ajout);
fenetre_afficher=create_gestion_utilisateur();
gtk_widget_show(fenetre_afficher);
treeview1=lookup_widget(fenetre_afficher,"treeview1");
afficher_user(treeview1);
}
}

void
on_afficher_user_clicked               (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;
fenetre_ajout=lookup_widget(objet,"ajouter");
gtk_widget_destroy(fenetre_ajout);

fenetre_afficher=create_gestion_utilisateur();
gtk_widget_show(fenetre_afficher);
treeview1=lookup_widget(fenetre_afficher,"treeview1");
afficher_user(treeview1);

}


void
on_quitajouter_user_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *winmen;
    	winmen=lookup_widget(button,"ajouter");
    	gtk_widget_destroy(winmen);
}



/*
void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


gboolean
on_treeview1_popup_menu                (GtkWidget       *widget,
                                        gpointer         user_data)
{

  return FALSE;
}


gboolean
on_treeview1_button_press_event        (GtkWidget       *widget,
                                        GdkEventButton  *event,
                                        gpointer         user_data)
{

  return FALSE;
}

*/
void
on_ajoutgu_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout;
GtkWidget *fenetre_afficher;

fenetre_afficher=lookup_widget(objet,"gestion_utilisateur");

gtk_widget_destroy(fenetre_afficher);
fenetre_ajout=lookup_widget(objet,"ajouter");
fenetre_ajout=create_ajouter();
gtk_widget_show(fenetre_ajout);
}


void
on_modifiergu_clicked                  (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_modif;
GtkWidget *fenetre_afficher;

fenetre_afficher=lookup_widget(objet,"gestion_utilisateur");

gtk_widget_destroy(fenetre_afficher);
fenetre_modif=lookup_widget(objet,"modif");
fenetre_modif=create_modif();
gtk_widget_show(fenetre_modif);
}


void
on_supprimergu_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_supprimer;
GtkWidget *fenetre_afficher;

fenetre_afficher=lookup_widget(objet,"gestion_utilisateur");

gtk_widget_destroy(fenetre_afficher);
fenetre_supprimer=lookup_widget(objet,"suppUser");
fenetre_supprimer=create_suppUser();
gtk_widget_show(fenetre_supprimer);
}


void
on_quitgu_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *winmen;
    	winmen=lookup_widget(button,"gestion_utilisateur");
    	gtk_widget_destroy(winmen);

}


void
on_recherchegu_clicked                 (GtkWidget        *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_rechercher;
GtkWidget *fenetre_afficher;
GtkWidget *cin;
GtkWidget *treeview1;
char rech[20];
cin = lookup_widget (objet, "esid");
strcpy(rech, gtk_entry_get_text(GTK_ENTRY(cin)));
fenetre_afficher=lookup_widget(objet,"gestion_utilisateur");
gtk_widget_destroy(fenetre_afficher);
fenetre_rechercher=lookup_widget(objet,"gestion_utilisateur");
fenetre_rechercher=create_gestion_utilisateur();
gtk_widget_show(fenetre_rechercher);
treeview1=lookup_widget(fenetre_rechercher,"treeview1");
rechercher_user(treeview1,rech);
}

void
on_retour_stat_clicked                 (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_stat;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;
fenetre_stat=lookup_widget(objet,"statistique");
gtk_widget_destroy(fenetre_stat);
fenetre_afficher=create_acceuil();
gtk_widget_show(fenetre_afficher);
}

void
on_quit_gestion_des_utilisateur_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_modif;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;
fenetre_modif=lookup_widget(objet,"gestion_utilisateur");
gtk_widget_destroy(fenetre_modif);

fenetre_afficher=create_acceuil();
gtk_widget_show(fenetre_afficher);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*void
on_modifierUser_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{

}

void
on_femmem_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_hommem_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_consultbut_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}
*/
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void
on_supprimer_utlisateur_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{  
}


void
on_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{       GtkWidget *input;
	GtkWidget *output;
	GtkWidget *fenetre_supp;
	GtkWidget *fenetre_afficher;
	GtkWidget *treeview1;
	char texte [100];
	char id[20];
	input = lookup_widget(objet,"entrysuppuser");
	strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));
	if(verifier_CIN(id)){
		supprimer_user(id);		
		sprintf(texte,"Votre suppression à été effectué avec succés\n");
		output = lookup_widget(objet,"mesgsup");
		GdkColor color;
		gdk_color_parse ("#40e61a", &color);
		gtk_widget_modify_fg (output, GTK_STATE_NORMAL, &color);
    		gtk_label_set_text(GTK_LABEL(output),texte);
		
	////////mchnbdel e supprimer mn objet graphique ll objet	
	}
	else{
		sprintf(texte,"Cette cin n'existe pas\n");
		output = lookup_widget(objet,"mesgsup");
		GdkColor color;
		gdk_color_parse ("#ff250d", &color);
		gtk_widget_modify_fg (output, GTK_STATE_NORMAL, &color);
    		gtk_label_set_text(GTK_LABEL(output),texte);	
		//
		//fenetre_supp=lookup_widget(objet,"suppUser");
		gtk_widget_destroy(fenetre_supp);
		fenetre_afficher=create_gestion_utilisateur();
		gtk_widget_show(fenetre_afficher);
		treeview1=lookup_widget(fenetre_afficher,"treeview1");
		afficher_user(treeview1);

	
}
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_confirmer_modif_clicked             (GtkWidget       *button,
                                        gpointer         user_data)
{
	GtkWidget *cin, *nom, *prenom, *sexe, *id_bureau, *jour, *mois, *annee, *email, *tel, *role,*vote ,*cin_errm,*nom_errm,*prenom_errm,*id_bureau_errm,*tel_errm,*email_errm,*role_errm;
	
	GtkWidget *fenetre_modif;
        GtkWidget *fenetre_afficher;
        GtkWidget *treeview1;

	cin = lookup_widget (button, "cinp");
	nom = lookup_widget (button, "nomp");
	prenom = lookup_widget (button, "prenomp");
	id_bureau = lookup_widget (button, "id_bureaup");
	jour = lookup_widget (button, "jourp");
	mois = lookup_widget (button, "moisp");
	annee = lookup_widget (button, "anneep");
	email = lookup_widget (button, "emailp");
	tel = lookup_widget (button, "telp");
	role = lookup_widget (button, "rolep");
	vote = lookup_widget(button,"votehsan");
	cin_errm = lookup_widget (button, "cin_errm");
	tel_errm = lookup_widget (button, "tel_errm");
        nom_errm = lookup_widget (button, "nom_errm");
	prenom_errm = lookup_widget (button, "prenom_errm");
	email_errm = lookup_widget (button, "email_errm");
	role_errm = lookup_widget (button, "role_errm");
	id_bureau_errm = lookup_widget (button, "id_bureau_errm");
        
	user u;
	date1 d;
	if (type== 1){
			strcpy(u.sexe,"homme");
		}
	else if(type== 2){
			strcpy(u.sexe,"femme");
		}
	
	strcpy(u.cin, gtk_entry_get_text(GTK_ENTRY(cin)));
	strcpy(u.nom, gtk_entry_get_text(GTK_ENTRY(nom)));
	strcpy(u.prenom, gtk_entry_get_text(GTK_ENTRY(prenom)));
	strcpy(u.id_bureau, gtk_entry_get_text(GTK_ENTRY(id_bureau)));
	strcpy(u.email, gtk_entry_get_text(GTK_ENTRY(email)));
	strcpy(u.tel, gtk_entry_get_text(GTK_ENTRY(tel)));
	strcpy(u.role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(role)));
	if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(vote))) {strcpy(u.vote,"1");}else{strcpy(u.vote,"0");};
	d.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
	d.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	d.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
	u.dateN=d; 	
	int test12=0;
	 if (strlen(u.id_bureau)!=7)
	{
	GdkColor color;
	    gdk_color_parse ("red", &color);
	    gtk_widget_modify_fg (id_bureau_errm, GTK_STATE_NORMAL, &color);

	gtk_label_set_text(GTK_LABEL(id_bureau_errm),"Vérifier id_bureau !");
	test12 =1;
	}else
	gtk_label_set_text(GTK_LABEL(id_bureau_errm),"");
	////////////
	if(strlen(u.tel)!=8){
	  GdkColor color;

	    gdk_color_parse ("red", &color);


	    gtk_widget_modify_fg (tel_errm, GTK_STATE_NORMAL, &color);
	gtk_label_set_text(GTK_LABEL(tel_errm),"Verifier le numéro de téléphone !");
	test12 =1;

	}else
	gtk_label_set_text(GTK_LABEL(tel_errm),"");
	/////
	if (verifier_CIN(u.cin)==0)
	{
	GdkColor color;

	    gdk_color_parse ("red", &color);


	    gtk_widget_modify_fg (cin_errm, GTK_STATE_NORMAL, &color);
	gtk_label_set_text(GTK_LABEL(cin_errm),"cin nest pas  existant !");
	test12 =1;

	}else if (strlen(u.cin)!=8)
	{
	GdkColor color;

	    gdk_color_parse ("red", &color);


	    gtk_widget_modify_fg (cin_errm, GTK_STATE_NORMAL, &color);
	gtk_label_set_text(GTK_LABEL(cin_errm),"Vérifier le cin !");
	test12 =1;}else

	gtk_label_set_text(GTK_LABEL(cin_errm),"");
	///
	if (strlen(u.email)==0)
	{
	GdkColor color;
	    gdk_color_parse ("red", &color);


	    gtk_widget_modify_fg (email_errm, GTK_STATE_NORMAL, &color);
	gtk_label_set_text(GTK_LABEL(email_errm),"Vérifier Email !");
	test12 =1;

	}else
	gtk_label_set_text(GTK_LABEL(email_errm),"");
	if(strlen(u.nom)==0){
	  GdkColor color;

	    gdk_color_parse ("red", &color);


	    gtk_widget_modify_fg (nom_errm, GTK_STATE_NORMAL, &color);
	gtk_label_set_text(GTK_LABEL(nom_errm),"Verifier le nom !");
	test12 =1;

	}else
	gtk_label_set_text(GTK_LABEL(nom_errm),"");
	if(strlen(u.prenom)==0){
	  GdkColor color;

	    gdk_color_parse ("red", &color);


	    gtk_widget_modify_fg (prenom_errm, GTK_STATE_NORMAL, &color);
	gtk_label_set_text(GTK_LABEL(prenom_errm),"Verifier le prenom !");
	test12 =1;

	}else
	gtk_label_set_text(GTK_LABEL(prenom_errm),"");
	if(strlen(u.role)==0){
	  GdkColor color;

	    gdk_color_parse ("red", &color);


	    gtk_widget_modify_fg (role_errm, GTK_STATE_NORMAL, &color);
	gtk_label_set_text(GTK_LABEL(role_errm),"Verifier le role !");
	test12 =1;
///////bdelet lena fenetre modif
	}else
	gtk_label_set_text(GTK_LABEL(role_errm),"");
	if (test12==0){
	modifier_user(u);
        fenetre_modif=lookup_widget(button,"modif");
	gtk_widget_destroy(fenetre_modif);
	fenetre_afficher=create_gestion_utilisateur();
	gtk_widget_show(fenetre_afficher);
	treeview1=lookup_widget(fenetre_afficher,"treeview1");
	afficher_user(treeview1);}
}

void
on_hommep_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active (GTK_RADIO_BUTTON(togglebutton)))
	type=1;
}


void
on_femmep_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active (GTK_RADIO_BUTTON(togglebutton)))
	type=2;
}


void
on_retourU_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_modif;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;
fenetre_modif=lookup_widget(objet,"modif");
gtk_widget_destroy(fenetre_modif);

fenetre_afficher=create_gestion_utilisateur();
gtk_widget_show(fenetre_afficher);
treeview1=lookup_widget(fenetre_afficher,"treeview1");
afficher_user(treeview1);
}


void
on_retoursuph_clicked                  (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_suppUser;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;
fenetre_suppUser=lookup_widget(objet,"suppUser");
gtk_widget_destroy(fenetre_suppUser);

fenetre_afficher=create_gestion_utilisateur();
gtk_widget_show(fenetre_afficher);
treeview1=lookup_widget(fenetre_afficher,"treeview1");
afficher_user(treeview1);
}

//////////////////////////////////////////consulter
void
on_consulter_utilisateur_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{




}


void
on_buttonloginconfirm_clicked          (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *cin, *mdp,*login_err;
user u,a;
char id[20];
cin = lookup_widget (button, "entryusernamelogin");
mdp = lookup_widget (button, "entrypasswordlogin");
login_err = lookup_widget (button, "labelconfirmsignup");
strcpy(u.cin, gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(u.password, gtk_entry_get_text(GTK_ENTRY(mdp)));
strcpy(id,u.cin);
if (login(u.cin,u.password)==1){
find_user(u.cin);


GtkWidget *windowlogin;
GtkWidget *acceuil_seconde;
//GtkWidget *treeview1;
windowlogin=lookup_widget(button,"windowlogin");
gtk_widget_destroy(windowlogin);
acceuil_seconde=create_acceuil_seconde();
gtk_widget_show(acceuil_seconde);
	}
else{


  GdkColor color;

    gdk_color_parse ("red", &color);

    gtk_widget_modify_fg (login_err, GTK_STATE_NORMAL, &color);
gtk_label_set_markup (GTK_LABEL (login_err), "<b>Vérifier vos cordonnées !</b>");
}
}


void
on_checkbuttonpasslogin_toggled        (GtkWidget        *objet,
                                        gpointer         user_data)
{
GtkWidget *passlock,*pass;
passlock=lookup_widget(objet,"checkbuttonpasslogin");
pass=lookup_widget(objet,"entrypasswordlogin");
if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(passlock)))
{
gtk_entry_set_visibility(pass,TRUE);
}
else
{
gtk_entry_set_visibility(pass,FALSE);
}
}


void
on_guacceuil_clicked                   (GtkWidget      *objet,
                                        gpointer         user_data)
{

GtkWidget *fenetre_afficher,*w1;
GtkWidget *treeview1;
w1=lookup_widget(objet,"acceuil");
fenetre_afficher=create_gestion_utilisateur();
gtk_widget_show(fenetre_afficher);
gtk_widget_destroy(w1);
treeview1=lookup_widget(fenetre_afficher,"treeview1");
afficher_user(treeview1);



}
void
on_consultation_clicked                (GtkButton       *objet,
                                        gpointer         user_data)
{
char id[20];
	GtkWidget *input1;
	input1 = lookup_widget(objet,"cinp");
	strcpy(id,gtk_entry_get_text(GTK_ENTRY(input1)));
//////
	char texte1[20],texte2[20],texte3[20],texte4[20],texte5[50];
	char outputmessage[100];
	GtkWidget *outputid_bureau;
	GtkWidget *outputnom;
	GtkWidget *outputprenom;
	GtkWidget *outputemail;
	GtkWidget *outputtel;	
	GtkWidget *tg1 ,*tg2,*jour ,*mois,*annee;
	GtkWidget *role;
	GtkWidget *outputt;
	GtkWidget *output10;
        user u;


		strcpy(u.id_bureau,find_user(id).id_bureau);
		strcpy(u.nom,find_user(id).nom);
		strcpy(u.prenom,find_user(id).prenom);
		strcpy(u.email,find_user(id).email);
		strcpy(u.tel,find_user(id).tel);
		tg1=lookup_widget(objet,"hommep");
		tg2=lookup_widget(objet,"femmep");
		
		if(strcmp(u.sexe,"homme")==0){gtk_toggle_button_set_active(GTK_RADIO_BUTTON (tg1),TRUE);}
		if(strcmp(u.sexe,"femme")==0){gtk_toggle_button_set_active(GTK_RADIO_BUTTON (tg2),TRUE);}
		
		sprintf(outputmessage,"Tapez vos nouveau donnée puis cliquez sur\n\tenregistrer vos modifications\n");
		output10 = lookup_widget(objet,"message");
		GdkColor color;
		gdk_color_parse ("#0c8ae8", &color);
		gtk_widget_modify_fg (output10, GTK_STATE_NORMAL, &color);
    		gtk_label_set_text(GTK_LABEL(output10),outputmessage);		

		sprintf(texte1,"%s",u.id_bureau);
		outputid_bureau = lookup_widget(objet,"id_bureaup");
    		gtk_entry_set_text(GTK_ENTRY(outputid_bureau),texte1);

		sprintf(texte2,"%s",u.prenom);
		outputprenom = lookup_widget(objet,"prenomp");
    		gtk_entry_set_text(GTK_ENTRY(outputprenom),texte2);
		
		sprintf(texte3,"%s",u.nom);
		outputnom = lookup_widget(objet,"nomp");
    		gtk_entry_set_text(GTK_ENTRY(outputnom),texte3);

		sprintf(texte4,"%s",u.tel);
		outputtel = lookup_widget(objet,"telp");
    		gtk_entry_set_text(GTK_ENTRY(outputtel),texte4);

		sprintf(texte5,"%s",u.email);
		outputemail = lookup_widget(objet,"emailp");
    		gtk_entry_set_text(GTK_ENTRY(outputemail),texte5);

		jour = lookup_widget(objet, "jourp");
		gtk_spin_button_set_value(GTK_SPIN_BUTTON(jour),find_user(id).dateN.jour);

		mois = lookup_widget(objet, "moisp");
		gtk_spin_button_set_value(GTK_SPIN_BUTTON(mois),find_user(id).dateN.mois);

		annee = lookup_widget(objet, "anneep");
		gtk_spin_button_set_value(GTK_SPIN_BUTTON(annee), find_user(id).dateN.annee);
		
		role = lookup_widget(objet, "rolep");
		int i = test_role(find_user(id).role);
		gtk_combo_box_set_active(GTK_COMBO_BOX(role),i);
}


void
on_buttonlogadmin_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;

	GtkWidget *window2,*mdp;

	window1 = lookup_widget(objet,"mainwindow");

	window2 = create_windowlogin ();

  	gtk_widget_show (window2);

	gtk_widget_destroy(window1);

	mdp = lookup_widget (window2, "entrypasswordlogin");

	gtk_entry_set_visibility(mdp,FALSE);
}


void
on_exitsupprimer_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
        GtkWidget *winmen;
    	winmen=lookup_widget(button,"suppUser");
    	gtk_widget_destroy(winmen);
}


void
on_exitmodif_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
        GtkWidget *winmen;
    	winmen=lookup_widget(button,"modif");
    	gtk_widget_destroy(winmen);
}


void
on_exitwindowlogin_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
        GtkWidget *winmen;
    	winmen=lookup_widget(button,"windowlogin");
    	gtk_widget_destroy(winmen);
}


void
on_deconnecter_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *winadd;
    	GtkWidget *winmen,*mdp;
    	winmen=lookup_widget(button,"acceuil");
    	winadd=create_windowlogin();
    	gtk_widget_show(winadd);
    	gtk_widget_destroy(winmen);
	mdp = lookup_widget (winadd, "entrypasswordlogin");

	gtk_entry_set_visibility(mdp,FALSE);
}


void
on_exitacceuil_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *winmen;
    	winmen=lookup_widget(button,"acceuil");
    	gtk_widget_destroy(winmen);
}


void
on_retourwindolwogin_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{     
        GtkWidget *window1;
	GtkWidget *window2;
	window1 = lookup_widget(objet,"windowlogin");
	window2 = create_mainwindow ();
  	gtk_widget_show (window2);
	gtk_widget_destroy(window1);
}


void
on_calculeAgemoy_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{      
 GtkWidget *input;
	GtkWidget *output;
	char outputmessage[20];
	input = lookup_widget(objet,"year_set");
	int year=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input));
	float moy=ageMoy(year);
	sprintf(outputmessage,"%.2f",moy);
	output = lookup_widget(objet,"showAgemoy");
    	gtk_label_set_text(GTK_LABEL(output),outputmessage);       	


}


void
on_calculeNbr_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{

        GtkWidget *input;
	GtkWidget *output;
	char outputmessage[20],id_bureaux[20];
	input = lookup_widget(objet,"id_burset");
	strcpy(id_bureaux,gtk_entry_get_text(GTK_ENTRY(input)));
	int total=nbrBureau(id_bureaux);
	sprintf(outputmessage,"%d",total);
	output = lookup_widget(objet,"showNbr");
    	gtk_label_set_text(GTK_LABEL(output),outputmessage);





}


void
on_statAcceuil_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *output;
GtkWidget *fenetre_afficher,*w1;
GtkWidget *treeview1;
w1=lookup_widget(objet,"acceuil");
fenetre_afficher=create_statistique();
gtk_widget_show(fenetre_afficher);
gtk_widget_destroy(w1);

}
////////////////////////////////////////////////////////////////////////////////**observateur
int profession;
int genre;
int T[3]={0,0,0};
void professions (int profession ,char prof[]){
if (profession == 1)
	strcpy(prof,"journaliste");
else if (profession == 2)
	strcpy(prof,"observateur");
else if (profession == 3)
	strcpy(prof,"interprete");
else if (profession == 4)
	strcpy(prof,"hote");

}
void genres (int genre ,char gnr[]){
if (genre == 0)
	strcpy(gnr,"homme");
else if (genre == 5)
	strcpy(gnr,"femme");
}

void
on_journaliste_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
		profession=1;
}


void
on_observateur_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
		profession=2;
}


void
on_hote_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
		profession=3;
}


void
on_interprete_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
		profession=4;
}


void
on_hommeo_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
genre=0;
}


void
on_femmeo_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
genre=5;
}

void
on_ajouter_ob_clicked                  (GtkButton       *button,
  
                                       gpointer         user_data)
{

GtkWidget *id, *nom, *prenom, *nationalite, *jour, *mois, *annee, *output;
char ide[20];
int iden;
observateur o,s;
GtkWidget *fenetre_ajout;
GtkWidget *fenetre_afficher;
GtkWidget *treeview2; 

id=lookup_widget(GTK_WIDGET(button),"ido");
nom=lookup_widget(GTK_WIDGET(button),"nomo");
prenom=lookup_widget(GTK_WIDGET(button),"prenomo");
jour=lookup_widget(GTK_WIDGET(button),"jouro");
mois=lookup_widget(GTK_WIDGET(button),"moiso");
annee=lookup_widget(GTK_WIDGET(button),"anneeo");
nationalite=lookup_widget(GTK_WIDGET(button),"nationalitee");
output=lookup_widget(GTK_WIDGET(button),"msgajob");

o.date_naissance.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
o.date_naissance.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
o.date_naissance.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));

strcpy(o.nationalite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(nationalite)));


strcpy(ide,gtk_entry_get_text(GTK_ENTRY(id)));
iden= atoi(ide);
o.id=iden;
strcpy(o.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(o.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
professions(profession,o.profession);
genres(genre,o.genre);
s=chercher(iden,"observateur.txt");

if (s.id!=-1)
	gtk_label_set_text(GTK_LABEL(output),"id existant!");
else {
int x=ajouter(o,"observateur.txt");
fenetre_ajout=lookup_widget(button,"ajouter_observateur");
gtk_widget_destroy(fenetre_ajout);
fenetre_afficher=create_gestion_observateur();
gtk_widget_show(fenetre_afficher);
treeview2=lookup_widget(fenetre_afficher,"treeview2");
afficher_observateur(treeview2);
}
}
void
on_g_ob_acceuil_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
/*
user u;
char texte[100];
GtkWidget *output;
GtkWidget *fenetre_afficher,*w1;
GtkWidget *treeview1;
w1=lookup_widget(objet,"acceuil");
fenetre_afficher=create_gestion_observateur();
FILE *f;
f=fopen("utilisateur.txt","r");
fscanf(f,"%s %s %s %s %d/%d/%d %s %s %s %s\n",u.cin,u.nom,u.prenom,u.id_bureau,&u.dateN.jour,&u.dateN.mois,&u.dateN.annee,u.email,u.tel,u.role,u.sexe,u.vote,u.password);
if(strcmp("ADMIN",u.role)==0){
gtk_widget_show(fenetre_afficher);
gtk_widget_destroy(w1);
treeview1=lookup_widget(fenetre_afficher,"treeview2");
afficher_observateur(treeview1);}
else{
		output = lookup_widget(objet,"label_acceuil");
		GdkColor color;
		gdk_color_parse ("#ff250d", &color);
		gtk_widget_modify_fg (output, GTK_STATE_NORMAL, &color);
		gtk_label_set_markup (GTK_LABEL (output), "<b>Accées Refusé vous n avez pas le droit  d accedez </b>");
}



*/








}
////////////////////////////////////////////////////////////////////

void
on_retour_g_ob_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_modif;
GtkWidget *fenetre_afficher;
fenetre_modif=lookup_widget(objet,"gestion_observateur");
gtk_widget_destroy(fenetre_modif);
fenetre_afficher=create_acceuil_seconde();
gtk_widget_show(fenetre_afficher);
}


void
on_aj_gob_clicked                      (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout;
GtkWidget *fenetre_afficher;
fenetre_afficher=lookup_widget(objet,"gestion_observateur");
gtk_widget_destroy(fenetre_afficher);
fenetre_ajout=lookup_widget(objet,"ajouter_Observateur");
fenetre_ajout=create_ajouter_Observateur();
gtk_widget_show(fenetre_ajout);
}


void
on_actualiser_ob_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget  *liste, *treeview2 ;
liste=lookup_widget(GTK_WIDGET(button),"gestion_observateurs");
liste=create_gestion_observateur();
gtk_widget_show(liste);
treeview2=lookup_widget(liste,"treeview2");
afficher_observateur(treeview2);
}

void
on_checkprofession_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
		T[2]=1;
}


void
on_checknationalite_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
		T[1]=1;
}


void
on_checkgenre_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
		T[0]=1;
}

void
on_recherche_multi_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *genre, *nationalite, *profession;
observateur test,o;
	
	if (T[0]==1 && T[1]==0 && T[2]==0){
		genre=lookup_widget(GTK_WIDGET(button),"rgenre");
		strcpy(test.genre,gtk_entry_get_text(GTK_ENTRY(genre)));
		FILE * f=fopen("observateur.txt", "r");
		FILE * f1=fopen("recherche.txt", "w");
		while(fscanf(f,"%d %s %s %s %s %s %d %d %d\n",&o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,&o.date_naissance.jour,&o.date_naissance.mois,&o.date_naissance.annee)!=EOF){
			if (strcmp(test.genre,o.genre)==0){
				fprintf(f1,"%d %s %s %s %s %s %d %d %d\n",o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,o.date_naissance.jour,o.date_naissance.mois,o.date_naissance.annee);
			}
}
fclose(f);
fclose(f1);

GtkWidget *supprimer, *liste, *treeview2 ;

supprimer=lookup_widget(GTK_WIDGET(button),"gestion_observateur");

gtk_widget_destroy(supprimer);

liste=lookup_widget(GTK_WIDGET(button),"gestion_observateur");

liste=create_gestion_observateur();

gtk_widget_show(liste);

treeview2=lookup_widget(liste,"treeview2");

affiche_observateur(treeview2);

T[0]=0;

		}
	else if (T[1]==1 && T[0]==0 && T[2]==0){
		nationalite=lookup_widget(GTK_WIDGET(button),"rnationalite");
		strcpy(test.nationalite,gtk_entry_get_text(GTK_ENTRY(nationalite)));
		FILE * f=fopen("observateur.txt", "r");
		FILE * f1=fopen("recherche.txt", "w");
		while(fscanf(f,"%d %s %s %s %s %s %d %d %d\n",&o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,&o.date_naissance.jour,&o.date_naissance.mois,&o.date_naissance.annee)!=EOF){
			if (strcmp(test.nationalite,o.nationalite)==0){
				fprintf(f1,"%d %s %s %s %s %s %d %d %d\n",o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,o.date_naissance.jour,o.date_naissance.mois,o.date_naissance.annee);
			}
}
fclose(f);
fclose(f1);

GtkWidget *supprimer, *liste, *treeview2 ;

supprimer=lookup_widget(GTK_WIDGET(button),"gestion_observateur");

gtk_widget_destroy(supprimer);

liste=lookup_widget(GTK_WIDGET(button),"gestion_observateur");

liste=create_gestion_observateur();

gtk_widget_show(liste);

treeview2=lookup_widget(liste,"treeview2");

affiche_observateur(treeview2);

T[1]=0;

		}
	else if (T[2]==1 && T[0]==0 && T[1]==0){
		profession=lookup_widget(GTK_WIDGET(button),"rprofession");
		strcpy(test.profession,gtk_entry_get_text(GTK_ENTRY(profession)));
		FILE * f=fopen("observateur.txt", "r");
		FILE * f1=fopen("recherche.txt", "w");
		while(fscanf(f,"%d %s %s %s %s %s %d %d %d\n",&o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,&o.date_naissance.jour,&o.date_naissance.mois,&o.date_naissance.annee)!=EOF){
			if (strcmp(test.profession,o.profession)==0){
				fprintf(f1,"%d %s %s %s %s %s %d %d %d\n",o.id,o.nom,o.prenom,o.nationalite,o.profession,o.genre,o.date_naissance.jour,o.date_naissance.mois,o.date_naissance.annee);
			}
}
fclose(f);
fclose(f1);

GtkWidget *supprimer, *liste, *treeview2 ;

supprimer=lookup_widget(GTK_WIDGET(button),"gestion_observateur");

gtk_widget_destroy(supprimer);

liste=lookup_widget(GTK_WIDGET(button),"gestion_observateur");

liste=create_gestion_observateur();

gtk_widget_show(liste);

treeview2=lookup_widget(liste,"treeview2");

affiche_observateur(treeview2);

T[2]=0;

		}
	else {
		GtkWidget *supprimer, *liste, *treeview2 ;

		supprimer=lookup_widget(GTK_WIDGET(button),"gestion_observateur");

		gtk_widget_destroy(supprimer);

		liste=lookup_widget(GTK_WIDGET(button),"gestion_observateur");

		liste=create_gestion_observateur();

		gtk_widget_show(liste);

		treeview2=lookup_widget(liste,"treeview2");

		afficher_observateur(treeview2);

		T[0]=0;

		T[1]=0;

		T[2]=0;

	}

}






void
on_retour_aj_gob1_clicked              (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;
fenetre_ajout=lookup_widget(objet,"ajouter_Observateur");
gtk_widget_destroy(fenetre_ajout);
fenetre_afficher=create_gestion_observateur();
gtk_widget_show(fenetre_afficher);
treeview1=lookup_widget(fenetre_afficher,"treeview2");
afficher_observateur(treeview1);
}
void
on_supp_obs_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
 GtkWidget *ID, *sortie;
char id[20];
int iden;
observateur o;

ID=lookup_widget(GTK_WIDGET(button),"id_obsr");
sortie=lookup_widget(GTK_WIDGET(button),"labl_obss");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(ID)));
iden= atoi(id);
o=chercher(iden,"observateur.txt");
if (o.id==-1)
	gtk_label_set_text(GTK_LABEL(sortie),"id n'exciste pas veillez saisir un neveau id!");
else{
	int x=supprimer_observateur(iden,"observateur.txt");

	GtkWidget *supprimer, *liste, *treeview ;

	supprimer=lookup_widget(GTK_WIDGET(button),"gestion_observateur");

	gtk_widget_destroy(supprimer);

	liste=lookup_widget(GTK_WIDGET(button),"gestion_observateur");

	liste=create_gestion_observateur();

	gtk_widget_show(liste);

	treeview=lookup_widget(liste,"treeview2");

	afficher_observateur(treeview);
	}
 }


void
on_supgob_clicked                      (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_supprimer;
GtkWidget *fenetre_afficher;

fenetre_afficher=lookup_widget(objet,"gestion_observateur");
gtk_widget_destroy(fenetre_afficher);
fenetre_supprimer=lookup_widget(objet,"supprimer_observateur");
fenetre_supprimer=create_supprimer_observateur();
gtk_widget_show(fenetre_supprimer);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////YESMINE///////////////////////////////////////////////////////
int typeyesmine=1;
int choix[]={0,0};
void
on_buttonajyesmine2_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *idbr,*idag,*Comboboxville,*Comboboxecole,*Comboboxcapelec,*Comboboxcapob,*spinbuttonsalle,*output,*output1;
GtkWidget *ajoutbureau;
bureau b;

ajoutbureau=lookup_widget(button,"ajoutbureau");

idbr=lookup_widget(button,"entryidbr");
idag=lookup_widget(button,"entryidag");
Comboboxville=lookup_widget(button,"comboboxville");
Comboboxecole=lookup_widget(button,"comboboxecole");
Comboboxcapelec=lookup_widget(button,"comboboxcapelec");
Comboboxcapob=lookup_widget(button,"comboboxcapob");
spinbuttonsalle=lookup_widget(button,"spinbuttonsalle");
output=lookup_widget(button,"labelidbrerr");
output1=lookup_widget(button,"labelidagerr");

int testyes=0;
strcpy(b.id_br,gtk_entry_get_text(GTK_ENTRY(idbr)));
strcpy(b.id_agent,gtk_entry_get_text(GTK_ENTRY(idag)));
strcpy(b.ville,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Comboboxville)));
strcpy(b.ecole,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Comboboxecole)));
strcpy(b.cap_elec,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Comboboxcapelec)));
strcpy(b.cap_obs,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Comboboxcapob)));

if(typeyesmine==1){
    strcpy(b.sexe,"femme");
}
if(typeyesmine==2){
    strcpy(b.sexe,"homme");
}

if(choix[0]==1){
 strcpy(b.role,"Précident");
 
}

if(choix[1]==1){
 strcpy(b.role,"Assesseurs");
 
}

if((choix[0]==1) && (choix[1]==1)){
 strcpy(b.role,"Précident/");
 strcat(b.role,"Assesseurs");
 
}


b.n_salle=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonsalle));



if (strlen(b.id_br)!=7)
{
    GdkColor color;

    gdk_color_parse ("red", &color);


    gtk_widget_modify_fg (output, GTK_STATE_NORMAL, &color);
    gtk_label_set_text(GTK_LABEL(output),"Vérifier ID bureau !");
    testyes =1;

}else if (verifier_idbr(b.id_br)==1)
{
     GdkColor color;

    gdk_color_parse ("red", &color);


    gtk_widget_modify_fg (output, GTK_STATE_NORMAL, &color);
   gtk_label_set_text(GTK_LABEL(output),"ID bureau déja existant !");
   testyes =1;

}else
    gtk_label_set_text(GTK_LABEL(output),"");
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////idagen

if (strlen(b.id_agent)!=8)
{
GdkColor color;

    gdk_color_parse ("red", &color);


    gtk_widget_modify_fg (output1, GTK_STATE_NORMAL, &color);
   gtk_label_set_text(GTK_LABEL(output1),"Verifier ID Agent !");
   testyes =1;

}

else
    gtk_label_set_text(GTK_LABEL(output1),"");
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
if(strlen(b.ville)==0){
  GdkColor color;

    gdk_color_parse ("red", &color);


    gtk_widget_modify_fg (output2, GTK_STATE_NORMAL, &color);
    gtk_label_set_text(GTK_LABEL(output2),"Verifier la ville !");
    testyes =1;
}
else
gtk_label_set_text(GTK_LABEL(output2),"");*/

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*if(strlen(b.ecole)==0){
  GdkColor color;

    gdk_color_parse ("red", &color);


    gtk_widget_modify_fg (output2, GTK_STATE_NORMAL, &color);
    gtk_label_set_text(GTK_LABEL(output3),"Verifier la municipalité !");
    testyes =1;
}
else
gtk_label_set_text(GTK_LABEL(output3),"");*/
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
if(strlen(b.cap_elec)==0){
  GdkColor color;

    gdk_color_parse ("red", &color);


    gtk_widget_modify_fg (output2, GTK_STATE_NORMAL, &color);
    gtk_label_set_text(GTK_LABEL(output4),"Verifier la capacité des électeurs !");
    testyes =1;
}
else
gtk_label_set_text(GTK_LABEL(output4),"");*/
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*if(strlen(b.cap_obs)==0){
  GdkColor color;

    gdk_color_parse ("red", &color);


    gtk_widget_modify_fg (output2, GTK_STATE_NORMAL, &color);
    gtk_label_set_text(GTK_LABEL(output5),"Verifier la capacité des observateurs !");
    testyes =1;
}
else
gtk_label_set_text(GTK_LABEL(output5),"");*/

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
if (testyes==0){

ajouter_br( b);}
}


void
on_afficherbr_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajoutbureau;
GtkWidget *gestionbureau;
GtkWidget *treeviewyesmine;

ajoutbureau=lookup_widget(button,"ajoutbureau");

gtk_widget_destroy(ajoutbureau);

gestionbureau=lookup_widget(button,"gestionbureau");
gestionbureau=create_gestionbureau();

gtk_widget_show(gestionbureau);

treeviewyesmine=lookup_widget(gestionbureau,"treeviewyesmine");

afficher_bureau(treeviewyesmine);



}


void
on_checkassure_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton)){
choix[1]=1;}

}


void
on_checkverif_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton)){
choix[0]=1;}

}


void
on_radiobutton2yes_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
   typeyesmine=2;

}


void
on_radiobutton1yes_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
   typeyesmine=1;

}


void
on_buttondefaut_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
int tab[2]={1,1};
GtkWidget *toggl1,*toggl2;


toggl1=lookup_widget(button,"checkverif");
toggl2=lookup_widget(button,"checkassure");

if (tab[0]==1){
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(toggl1),TRUE);
}
if (tab[1]==1){
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(toggl2),TRUE);
}

}


void
on_retouryesmine_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajoutbureau, *gestionbureau,*treeviewyesmine;
ajoutbureau=lookup_widget(button,"ajoutbureau");
gtk_widget_destroy(ajoutbureau);
gestionbureau=create_gestionbureau();
gtk_widget_show(gestionbureau);
///////////
treeviewyesmine=lookup_widget(gestionbureau,"treeviewyesmine");
afficher_bureau(treeviewyesmine);

}


void
on_buttonajyesmine_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajoutbureau;
GtkWidget *gestionbureau;
gestionbureau=lookup_widget(button,"gestionbureau");
gtk_widget_destroy(gestionbureau);
ajoutbureau=create_ajoutbureau();
gtk_widget_show(ajoutbureau);

}


void
on_buttonmodyesmine_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *modifierbureau;
GtkWidget *gestionbureau;
gestionbureau=lookup_widget(button,"gestionbureau");
gtk_widget_destroy(gestionbureau);
modifierbureau=create_modifierbureau();
gtk_widget_show(modifierbureau);

}


void
on_buttonsuppyesmine_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *supprimerbr, *gestionbureau;
gestionbureau=lookup_widget(button,"gestionbureau");
gtk_widget_destroy(gestionbureau);
supprimerbr=create_supprimerbr();
gtk_widget_show(supprimerbr);
}


void
on_buttonactualiserbr_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *gestionbureau,*w1;
GtkWidget *treeviewyesmine;
w1=lookup_widget(button,"gestionbureau");
gestionbureau=create_gestionbureau();
gtk_widget_show(gestionbureau);
gtk_widget_hide(w1);
treeviewyesmine=lookup_widget(gestionbureau,"treeviewyesmine");
viderbr(treeviewyesmine);
afficher_bureau(treeviewyesmine);

}


void
on_buttonrechercheyesmine_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *gestionbureau;
GtkWidget *chercherbureau;
GtkWidget *idbr,*output;
GtkWidget *treeviewyesmine;
char rechbr[30];
idbr=lookup_widget(button,"entryrechercheyesmine");
output=lookup_widget(button,"rechrech");
int testyes=0;
strcpy(rechbr,gtk_entry_get_text(GTK_ENTRY(idbr)));
gestionbureau=lookup_widget(button,"gestionbureau");
gtk_widget_destroy(gestionbureau);
chercherbureau=lookup_widget(button,"gestionbureau");
chercherbureau=create_gestionbureau();
gtk_widget_show(chercherbureau);
treeviewyesmine=lookup_widget(chercherbureau,"treeviewyesmine");
if (verifier_idbr(rechbr)==0)
	{
	GdkColor color;

	    gdk_color_parse ("red", &color);


	    gtk_widget_modify_fg (output, GTK_STATE_NORMAL, &color);
	gtk_label_set_text(GTK_LABEL(output),"❌");
	testyes =1;

	}
       else

	gtk_label_set_text(GTK_LABEL(output),"");

 if (testyes==0){

   rechercher_bureau(treeviewyesmine,rechbr);
               }







}


void
on_gbvAcceuil_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *output;
GtkWidget *fenetre_afficher,*w1;
GtkWidget *treeview1;
w1=lookup_widget(objet,"acceuil");
fenetre_afficher=create_gestionbureau();
gtk_widget_show(fenetre_afficher);
gtk_widget_destroy(w1);
treeview1=lookup_widget(fenetre_afficher,"treeviewyesmine");
afficher_bureau(treeview1);
//////////////////////////////////////////////////////////////////////////
/*
user u;
char texte[100];
GtkWidget *output;
GtkWidget *fenetre_afficher,*w1;
GtkWidget *treeview1;
w1=lookup_widget(objet,"acceuil");
fenetre_afficher=create_gestionbureau();
FILE *f;
f=fopen("utilisateur.txt","r");
fscanf(f,"%s %s %s %s %d/%d/%d %s %s %s %s\n",u.cin,u.nom,u.prenom,u.id_bureau,&u.dateN.jour,&u.dateN.mois,&u.dateN.annee,u.email,u.tel,u.role,u.sexe,u.vote,u.password);
if(strcmp("AGENT-de-bureau",u.role)||strcmp("ADMIN",u.role)==0){
gtk_widget_show(fenetre_afficher);
gtk_widget_destroy(w1);
treeview1=lookup_widget(fenetre_afficher,"treeviewyesmine");
afficher_bureau(treeview1);}
else{
		output = lookup_widget(objet,"label_acceuil");
		GdkColor color;
		gdk_color_parse ("#ff250d", &color);
		gtk_widget_modify_fg (output, GTK_STATE_NORMAL, &color);
		gtk_label_set_markup (GTK_LABEL (output), "<b>Accées Refusé vous n avez pas le droit  d accedez </b>");
}


*/

}

int type2yesmine=1;
int choix2[]={0,0};

void
on_buttonmodyesmine2_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *idbr2,*idag2,*Comboboxville2,*Comboboxecole2,*Comboboxcapelec2,*Comboboxcapob2,*spinbuttonsalle2;
GtkWidget *modifierbureau;
GtkWidget* output ,*output1;
bureau b;

modifierbureau=lookup_widget(button,"modifierbureau");

idbr2=lookup_widget(button,"entryidbr2");
idag2=lookup_widget(button,"entryidag2");
Comboboxville2=lookup_widget(button,"comboboxville2");
Comboboxecole2=lookup_widget(button,"comboboxecole2");
Comboboxcapelec2=lookup_widget(button,"comboboxcapelec2");
Comboboxcapob2=lookup_widget(button,"comboboxcapob2");
spinbuttonsalle2=lookup_widget(button,"spinbuttonsalle2");
output = lookup_widget(button, "labelidbrmoderr") ;
output1 = lookup_widget(button, "labelidagmoderr") ;

int testyes=0;
strcpy(b.id_br,gtk_entry_get_text(GTK_ENTRY(idbr2)));
strcpy(b.id_agent,gtk_entry_get_text(GTK_ENTRY(idag2)));
strcpy(b.ville,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Comboboxville2)));
strcpy(b.ecole,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Comboboxecole2)));
strcpy(b.cap_elec,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Comboboxcapelec2)));
strcpy(b.cap_obs,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Comboboxcapob2)));

if(type2yesmine==1){
    strcpy(b.sexe,"femme");
}
if(type2yesmine==2){
    strcpy(b.sexe,"homme");
}

if(choix2[0]==1){
 strcpy(b.role,"Précident");
 
}

if(choix2[1]==1){
 strcpy(b.role,"assesseurs");
 
}

if((choix2[0]==1) && (choix2[1]==1)){
 strcpy(b.role,"Précident/");
 strcat(b.role,"Assesseurs");
 
}


b.n_salle=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonsalle2));
//gtk_label_set_text(GTK_LABEL(output),"la modification a été faite avec succés");  
////////////////////////////////////////////////////////////////////////////////////////////
if (verifier_idbr(b.id_br)==0)
	{
	GdkColor color;

	    gdk_color_parse ("red", &color);


	    gtk_widget_modify_fg (output, GTK_STATE_NORMAL, &color);
	gtk_label_set_text(GTK_LABEL(output),"ID n'existe pas!");
	testyes =1;

	}else if (strlen(b.id_br)!=7)
	{
	GdkColor color;

	    gdk_color_parse ("red", &color);


	    gtk_widget_modify_fg (output, GTK_STATE_NORMAL, &color);
	gtk_label_set_text(GTK_LABEL(output),"Vérifier ID bureau!");
	testyes =1;}else

	gtk_label_set_text(GTK_LABEL(output),"");

if(strlen(b.id_agent)!=8){
  GdkColor color;
      gdk_color_parse("red",&color);
      gtk_widget_modify_fg(output1,GTK_STATE_NORMAL,&color);
      gtk_label_set_text(GTK_LABEL(output1),"Vérifier ID agent");
      testyes=1;}
       else
       gtk_label_set_text(GTK_LABEL(output1),"");





if (testyes==0){
   modifier_bureau( b);}



}




void
on_radiobuttonhommebr_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
   type2yesmine=2;

}


void
on_radiobuttonfemmebr_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
   type2yesmine=2;
}


void
on_checkverif2_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton)){
choix2[0]=1;}

}


void
on_checkassure2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton)){
choix2[1]=1;}

}


void
on_retouryesmine2_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *modifierbureau, *gestionbureau,*treeviewyesmine;
modifierbureau=lookup_widget(button,"modifierbureau");
gtk_widget_destroy(modifierbureau);
gestionbureau=create_gestionbureau();
gtk_widget_show(gestionbureau);
///////////
treeviewyesmine=lookup_widget(gestionbureau,"treeviewyesmine");
afficher_bureau(treeviewyesmine);

}


void
on_buttonsuppbr_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
bureau b;
GtkWidget *input;
GtkWidget* output ;
char idb[30];
char texte[100];
input=lookup_widget(button,"entry_supp_br");
//output = lookup_widget(button, "labelsupbureau") ;
strcpy(idb,gtk_entry_get_text(GTK_ENTRY(input)));  
if(verifier_idbr(idb)){
		supprimer_br(idb);		
		sprintf(texte,"Votre suppression à été effectué avec succés\n");
		output = lookup_widget(button,"labelsupprimerbr");
		GdkColor color;
		gdk_color_parse ("#40e61a", &color);
		gtk_widget_modify_fg (output, GTK_STATE_NORMAL, &color);
    		gtk_label_set_text(GTK_LABEL(output),texte);}
else{
		sprintf(texte,"l'id n'existe pas\n");
		output = lookup_widget(button,"labelsupprimerbr");
		GdkColor color;
		gdk_color_parse ("#ff250d", &color);
		gtk_widget_modify_fg (output, GTK_STATE_NORMAL, &color);
    		gtk_label_set_text(GTK_LABEL(output),texte);}


}


void
on_retouryesmine3_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *supprimer, *gestionbureau,*treeviewyesmine;
supprimer=lookup_widget(button,"supprimer");
gtk_widget_destroy(supprimer);
gestionbureau=create_gestionbureau();
gtk_widget_show(gestionbureau);
////////////
treeviewyesmine=lookup_widget(gestionbureau,"treeviewyesmine");
afficher_bureau(treeviewyesmine);

}


void
on_retouryesmine4_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *acceuil, *gestionbureau;
gestionbureau=lookup_widget(button,"gestionbureau");
gtk_widget_destroy(gestionbureau);
acceuil=create_acceuil();
gtk_widget_show(acceuil);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////FARAH///////////////////////////////////////////////////////////////////////
int typefarah=1;
int type2farah=1;
void
on_confirmer_ajouter_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GestionElection E;
   GtkWidget *spinbuttonjour_ajou, *spinbuttonmois_ajou, *spinbuttonannee_ajou,*entryidajou ,*comboboxmuni_ajou ,*comboboxhb_ajou ,*outputfarah;
   GtkWidget *ajouter_election;
   GtkWidget *gestion_election;
   GtkWidget *treeviewfarah;

   ajouter_election=lookup_widget(button,"ajouter_election");

   spinbuttonjour_ajou=lookup_widget(button,"spinbuttonjour_ajou");
   spinbuttonmois_ajou=lookup_widget(button,"spinbuttonmois_ajou");
   spinbuttonannee_ajou=lookup_widget(button,"spinbuttonannee_ajou");

   entryidajou=lookup_widget(button,"entryidajou");

   comboboxmuni_ajou=lookup_widget(button,"comboboxmuni_ajou");

   comboboxhb_ajou=lookup_widget(button,"comboboxhb_ajou");
   
   outputfarah=lookup_widget(button,"afficheerreur");

   E.date_election.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonjour_ajou));
   E.date_election.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonmois_ajou));
   E.date_election.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonannee_ajou));

   strcpy(E.id,gtk_entry_get_text(GTK_ENTRY(entryidajou)));

   strcpy(E.municipalite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxmuni_ajou)));
    
   strcpy(E.nb_habitant,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxhb_ajou)));

   if(typefarah==1){
      strcpy(E.ville,"mahdia");}

  else if(typefarah==2){
      strcpy(E.ville,"sfax");}
  else if(typefarah==3){
      strcpy(E.ville,"tunis");}
    
  int x=0;
   x=control_id(E.id);
  if(x==1){
       GdkColor color;
       gdk_color_parse("red",&color);
       gtk_widget_modify_fg(outputfarah,GTK_STATE_NORMAL,&color);
      gtk_label_set_text(GTK_LABEL(outputfarah),"id existe deja");}
  else if(strlen(E.id)!=8){
     GdkColor color;
       gdk_color_parse("red",&color);
       gtk_widget_modify_fg(outputfarah,GTK_STATE_NORMAL,&color);
      gtk_label_set_text(GTK_LABEL(outputfarah),"il faut 8chiffre");
    }
    else {
      ajouter_elections(E);
  
    gtk_widget_destroy(ajouter_election);
   //gestion_election=lookup_widget(objet_graphique,"gestion_election");
   gestion_election=create_gestion_election();
 
   gtk_widget_show(gestion_election);
  
   treeviewfarah=lookup_widget(gestion_election,"treeviewfarah");

   afficher_elections(treeviewfarah);}



}


void
on_return_de_ajouter_gest_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajouter_election;
   GtkWidget *gestion_election;
  GtkWidget *treeview1;

   ajouter_election=lookup_widget(button,"ajouter_election");

   gtk_widget_destroy(ajouter_election);
   gestion_election=create_gestion_election();
 
   gtk_widget_show(gestion_election);

   treeview1=lookup_widget(gestion_election,"treeviewfarah");

   afficher_elections(treeview1);

}


void
on_radiobuttonvill3_ajou_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
  if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    typefarah=3;
}


void
on_radiobuttonvill2_ajou_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
 if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    typefarah=2;

}


void
on_radiobuttonvill1_ajou_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
 if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    typefarah=1;
}


void
on_rechercher_election_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *gestion_election;
 GtkWidget *chercher_election;
 GtkWidget *idele;
 GtkWidget *treeview1;
 char rechele[30];
 idele=lookup_widget(button,"entryrecher");
 strcpy(rechele,gtk_entry_get_text(GTK_ENTRY(idele)));
 gestion_election=lookup_widget(button,"gestion_election");
 gtk_widget_destroy(gestion_election);
 chercher_election=lookup_widget(button,"gestion_election");
   
   chercher_election=create_gestion_election();
 
   gtk_widget_show(chercher_election);
  
   treeview1=lookup_widget(chercher_election,"treeviewfarah");

   rechercher_elections(treeview1,rechele);

}


void
on_ajouter_election_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
 GtkWidget *ajouter_election;
   GtkWidget *gestion_election;

   gestion_election=lookup_widget(button,"gestion_election");
   gtk_widget_destroy(gestion_election);
   ajouter_election=create_ajouter_election();
   gtk_widget_show(ajouter_election);

}


void
on_modifier_election_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
 GtkWidget *modifier_election;
   GtkWidget *gestion_election;

   gestion_election=lookup_widget(button,"gestion_election");

   gtk_widget_destroy(gestion_election);
   modifier_election=create_modifier_election();
 
   gtk_widget_show(modifier_election);

}


void
on_supprimer_election_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
 GtkWidget *supprimer_election;
   GtkWidget *gestion_election;

   gestion_election=lookup_widget(button,"gestion_election");

   gtk_widget_destroy(gestion_election);
   supprimer_election=create_supprimer_election();
 
   gtk_widget_show(supprimer_election);

}


void
on_return_de_supp_gest_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
   GtkWidget *supprimer_election;
   GtkWidget *gestion_election;
   GtkWidget *treeview1;

   supprimer_election=lookup_widget(button,"supprimer_election");

   gtk_widget_destroy(supprimer_election);
   gestion_election=create_gestion_election();
 
   gtk_widget_show(gestion_election);

   treeview1=lookup_widget(gestion_election,"treeviewfarah");

   afficher_elections(treeview1);

}


void
on_confirmer_supprimer_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
 GestionElection E;
  GtkWidget *input;
  GtkWidget *supprimer_election;
  GtkWidget *gestion_election;
  GtkWidget *treeview1;

  supprimer_election=lookup_widget(button,"supprimer_election");

  char idele[9];
  input=lookup_widget(button,"entryid_sup");
  strcpy(idele,gtk_entry_get_text(GTK_ENTRY(input)));
  supprimer_elections(idele);

  gtk_widget_destroy(supprimer_election);

  gestion_election=create_gestion_election();
 
   gtk_widget_show(gestion_election);
  
   treeview1=lookup_widget(gestion_election,"treeviewfarah");

   afficher_elections(treeview1);

}


void
on_return_de_modi_gest_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
  GtkWidget *modifier_election;
   GtkWidget *gestion_election;
   GtkWidget *treeview1;

   modifier_election=lookup_widget(button,"modifier_election");
   gtk_widget_destroy(modifier_election);
   gestion_election=create_gestion_election();
   gtk_widget_show(gestion_election);
  
   treeview1=lookup_widget(gestion_election,"treeviewfarah");

   afficher_elections(treeview1);
}


void
on_confirmer_modifier_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{

GestionElection E;
   GtkWidget *spinbuttonjour_modi, *spinbuttonmois_modi, *spinbuttonannee_modi,*entryidmod ,*comboboxmuni_modi ,*comboboxhb_modi ;
   GtkWidget *modifier_election;
   GtkWidget *gestion_election;
  /* GtkWidget *treeview1;*/

   modifier_election=lookup_widget(button,"modifier_election");

    entryidmod=lookup_widget(button,"entryidmod");

   spinbuttonjour_modi=lookup_widget(button,"spinbuttonjour_modi");
   spinbuttonmois_modi=lookup_widget(button,"spinbuttonmois_modi");
   spinbuttonannee_modi=lookup_widget(button,"spinbuttonannee_modi");
   comboboxmuni_modi=lookup_widget(button,"comboboxmuni_modi");
   comboboxhb_modi=lookup_widget(button,"comboboxnh_modi");

   strcpy(E.id,gtk_entry_get_text(GTK_ENTRY(entryidmod)));
   
   E.date_election.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonjour_modi));
   E.date_election.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonmois_modi));
   E.date_election.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonannee_modi));

   if(type2farah==1){
      strcpy(E.ville,"mahdia");}

   if(type2farah==2){
      strcpy(E.ville,"sfax");}
  if(type2farah==3){
      strcpy(E.ville,"tunis");}

   strcpy(E.municipalite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxmuni_modi)));
   strcpy(E.nb_habitant,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxhb_modi)));
    modifier_elections(E);
  



}


void
on_radiobuttonvill1_modi_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
 if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    type2farah=1;

}


void
on_radiobuttonvill3_modi_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
 if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    type2farah=3;


}


void
on_radiobuttonvill2_modi_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
 if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    type2farah=2;


}




void
on_quit_gu_stat_clicked                (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_stat;
GtkWidget *fenetre_afficher;

fenetre_afficher=lookup_widget(objet,"gestion_utilisateur");

gtk_widget_destroy(fenetre_afficher);
fenetre_stat=lookup_widget(objet,"statistique");
fenetre_stat=create_statistique();
gtk_widget_show(fenetre_stat);
}


void
on_geAcceuil_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{

user u;
char texte[100];
GtkWidget *output;
GtkWidget *fenetre_afficher,*w1;
GtkWidget *treeviewfarah;
w1=lookup_widget(objet,"acceuil");
fenetre_afficher=create_gestion_election();
gtk_widget_show(fenetre_afficher);
gtk_widget_destroy(w1);
treeviewfarah=lookup_widget(fenetre_afficher,"treeviewfarah");
afficher_elections(treeviewfarah);
/*
FILE *f;
f=fopen("utilisateur.txt","r");
fscanf(f,"%s %s %s %s %d/%d/%d %s %s %s %s %s %s\n",u.cin,u.nom,u.prenom,u.id_bureau,&u.dateN.jour,&u.dateN.mois,&u.dateN.annee,u.email,u.tel,u.role,u.sexe,u.vote,u.password);
if(strcmp("ADMIN",u.role)==0){
gtk_widget_show(fenetre_afficher);
gtk_widget_destroy(w1);
treeviewfarah=lookup_widget(fenetre_afficher,"treeviewfarah");
afficher_elections(treeviewfarah);}
else{
		output = lookup_widget(objet,"label_acceuil");
		GdkColor color;
		gdk_color_parse ("#ff250d", &color);
		gtk_widget_modify_fg (output, GTK_STATE_NORMAL, &color);
		gtk_label_set_markup (GTK_LABEL (output), "<b>Accées Refusé</b>");



}*/
}

void
on_retourf_acc_clicked                 (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_modif;
GtkWidget *fenetre_afficher;
fenetre_modif=lookup_widget(objet,"gestion_election");
gtk_widget_destroy(fenetre_modif);
fenetre_afficher=create_acceuil();
gtk_widget_show(fenetre_afficher);
}


void
on_ge_stat_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_stat;
GtkWidget *fenetre_afficher;

fenetre_afficher=lookup_widget(objet,"gestion_election");

gtk_widget_destroy(fenetre_afficher);
fenetre_stat=lookup_widget(objet,"statistique");
fenetre_stat=create_statistique();
gtk_widget_show(fenetre_stat);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////YESMINE2////////////////////////////////


void
on_buttonagentyes_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
 char id[20];
        char texte[20];
       
	char outputmessage[100];
	GtkWidget *outputid_br;
	GtkWidget *outputid_ag;
        bureau b;
        user u;
 
	GtkWidget *input1;
	input1 = lookup_widget(button,"entryidbr");
	strcpy(id,gtk_entry_get_text(GTK_ENTRY(input1)));


         strcpy(u.cin,find_ag(id).cin);
         sprintf(texte,"%s",u.cin);
         outputid_ag = lookup_widget(button,"entryidag");
         gtk_entry_set_text(GTK_ENTRY(outputid_ag),texte);


}


void
on_buttonconsulterbr_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

   char id[20];
	GtkWidget *input1;
	input1 = lookup_widget(button,"entryidbr2");
	strcpy(id,gtk_entry_get_text(GTK_ENTRY(input1)));

	char texte2[20];
       //char texte2[20],texte3[20],texte4[20],texte5[20];
	char outputmessage[100];
	GtkWidget *outputid_br;
	GtkWidget *outputid_ag;
        bureau b;
	/*GtkWidget *outputprenom;
	GtkWidget *outputemail;
	GtkWidget *outputtel;	
	*/GtkWidget *tg1 ,*tg2;
	GtkWidget *capelec;
        GtkWidget *capob;
        GtkWidget *capville;
        GtkWidget *capecole;
        GtkWidget *spinbuttonsalle2;
	/*GtkWidget *outputt;
	GtkWidget *output10;
        
		
		*/strcpy(b.id_agent,find_br(id).id_agent);
		
		tg1=lookup_widget(button,"radiobuttonfemmebr2");
		tg2=lookup_widget(button,"radiobuttonhommebr2");
		
		if(strcmp(b.sexe,"femme")==0){gtk_toggle_button_set_active(GTK_RADIO_BUTTON (tg1),TRUE);}
		if(strcmp(b.sexe,"homme")==0){gtk_toggle_button_set_active(GTK_RADIO_BUTTON (tg2),TRUE);}
		
		/*sprintf(outputmessage,"Tapez vos nouveau donnée puis cliquez sur\n\tenregistrer vos modifications\n");
		output10 = lookup_widget(objet,"message");
		GdkColor color;
		gdk_color_parse ("#0c8ae8", &color);
		gtk_widget_modify_fg (output10, GTK_STATE_NORMAL, &color);
    		gtk_label_set_text(GTK_LABEL(output10),outputmessage);*/	

		

		sprintf(texte2,"%s",b.id_agent);
		outputid_ag = lookup_widget(button,"entryidag2");
    		gtk_entry_set_text(GTK_ENTRY(outputid_ag),texte2);

                capelec = lookup_widget(button, "comboboxcapelec2");
		int i = test_capelec(find_br(id).cap_elec);
		gtk_combo_box_set_active(GTK_COMBO_BOX(capelec),i);


                capob = lookup_widget(button, "comboboxcapob2");
		int j = test_capob(find_br(id).cap_obs);
		gtk_combo_box_set_active(GTK_COMBO_BOX(capob),j);



                capville = lookup_widget(button, "comboboxville2");
		int k = test_capob(find_br(id).ville);
		gtk_combo_box_set_active(GTK_COMBO_BOX(capville),k);

                capecole = lookup_widget(button, "comboboxecole2");
		int l = test_ecole(find_br(id).ecole);
		gtk_combo_box_set_active(GTK_COMBO_BOX(capecole),l);
		
		


		spinbuttonsalle2 = lookup_widget(button, "spinbuttonsalle2");
		gtk_spin_button_set_value(GTK_SPIN_BUTTON(spinbuttonsalle2),find_br(id).n_salle);



}
int choixvilleyes[]={0,0,0};

void
on_cheryesmine_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *gestionbureau;
GtkWidget *chercherbureau;
//GtkWidget *idbr,*output;
GtkWidget *treeviewyesmine;
if (choixvilleyes[0]==1){

   gestionbureau=lookup_widget(button,"gestionbureau");
   gtk_widget_destroy(gestionbureau);
   chercherbureau=lookup_widget(button,"gestionbureau");
   chercherbureau=create_gestionbureau();
   gtk_widget_show(chercherbureau);
   treeviewyesmine=lookup_widget(chercherbureau,"treeviewyesmine");
   rechercher_tunis_yes(treeviewyesmine);}
if (choixvilleyes[1]==1){

   gestionbureau=lookup_widget(button,"gestionbureau");
   gtk_widget_destroy(gestionbureau);
   chercherbureau=lookup_widget(button,"gestionbureau");
   chercherbureau=create_gestionbureau();
   gtk_widget_show(chercherbureau);
   treeviewyesmine=lookup_widget(chercherbureau,"treeviewyesmine");
   rechercher_mahdia_yes(treeviewyesmine);}
if (choixvilleyes[2]==1){

   gestionbureau=lookup_widget(button,"gestionbureau");
   gtk_widget_destroy(gestionbureau);
   chercherbureau=lookup_widget(button,"gestionbureau");
   chercherbureau=create_gestionbureau();
   gtk_widget_show(chercherbureau);
   treeviewyesmine=lookup_widget(chercherbureau,"treeviewyesmine");
   rechercher_sfax_yes(treeviewyesmine);}

}


void
on_checkvilleyesmine1_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton)){
choixvilleyes[0]=1;}


}


void
on_checkvilleyesmine2_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton)){
choixvilleyes[1]=1;}
}


void
on_checkvilleyesmine3_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton)){
choixvilleyes[2]=1;}

}

/***********************************************/


void
on_retour_obv_supp_clicked             (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_suppobv;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;
fenetre_suppobv=lookup_widget(objet,"supprimer_observateur");
gtk_widget_destroy(fenetre_suppobv);
fenetre_afficher=create_gestion_observateur();
gtk_widget_show(fenetre_afficher);
treeview1=lookup_widget(fenetre_afficher,"treeview2");
afficher_observateur(treeview1);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////houssem////////////////////////////////////////////////////////////////
int w=1,z=1;
void
on_buttonajouterliste_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input1;
	GtkWidget *input2;
	GtkWidget *input3;
	GtkWidget *input4;
	GtkWidget *input5;
	GtkWidget *input6;
	GtkWidget *input7;
	GtkWidget *input8;
	GtkWidget *input9;
	GtkWidget *output;
	GtkWidget *output1;

	
	int p;

	char texte[200];

	liste c;

	input1=lookup_widget(objet,"idliste");
	input2=lookup_widget(objet,"idpresident");
	input3=lookup_widget(objet,"comboboxentryorientation");
	input4=lookup_widget(objet,"entryprogramme");
	input5=lookup_widget(objet,"nompresident");
	input9=lookup_widget(objet,"prenompresident");
	input6=lookup_widget(objet,"spinbuttonjourliste");
	input7=lookup_widget(objet,"spinbuttonmoisliste");
	input8=lookup_widget(objet,"spinbuttonanneeliste");
	
	if (w== 1){
		strcpy(c.sexe,"homme");
	}
	else if(w== 2){
		strcpy(c.sexe,"femme");
	}

	strcpy(c.idliste,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(c.idpresidentliste,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(c.orinetation,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input3)));
	strcpy(c.programmeelectorale,gtk_entry_get_text(GTK_ENTRY(input4)));
	strcpy(c.nompresident,gtk_entry_get_text(GTK_ENTRY(input5)));
	strcpy(c.prenompresident,gtk_entry_get_text(GTK_ENTRY(input9)));
	c.jourcliste=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input6));
	c.moiscliste=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input7));
	c.anneecliste=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input8));
	strcpy(c.vote,"🆕");
	
	p=idExist(c.idliste);
	output1 = lookup_widget(objet,"labelid");
	if(!p){
		ajouter_liste(c);
		gtk_label_set_text(GTK_LABEL(output1),"✔️ \n Cet un nouvel id");
		sprintf(texte,"liste ajouté avec succés");
		output = lookup_widget(objet,"labeladdliste");
		GdkColor color;
		gdk_color_parse ("#40e61a", &color);
		gtk_widget_modify_fg (output, GTK_STATE_NORMAL, &color);
    		gtk_label_set_text(GTK_LABEL(output),texte);}
	else{
		gtk_label_set_text(GTK_LABEL(output1),"❌ \n id existant");
		sprintf(texte,"Verfier vos données !");
		output = lookup_widget(objet,"labeladdliste");
		GdkColor color;
		gdk_color_parse ("#ff250d", &color);
		gtk_widget_modify_fg (output, GTK_STATE_NORMAL, &color);
    		gtk_label_set_text(GTK_LABEL(output),texte);}

}


void
on_backaddliste_clicked                (GtkWidget      *objet,
                                        gpointer         user_data)
{
        GtkWidget *window;
	GtkWidget *window1;
	GtkWidget *treeview;
	window = lookup_widget(objet,"ajoutliste");
	window1 = create_listes ();
	gtk_widget_destroy(window);
	gtk_widget_show(window1);	
	treeview = lookup_widget(window1,"treeviewlistes");	
	afficher_liste(treeview);

}


void
on_radiobuttonhommeliste_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
        w = 2;
	}

}


void
on_radiobuttonfemmeliste_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
        w = 1;
	}

}


void
on_buttongotoaddliste_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
        GtkWidget *window;
	GtkWidget *window1;
	
	window = lookup_widget(objet,"listes");
	window1 = create_ajoutliste();
	gtk_widget_destroy(window);
	gtk_widget_show(window1);

}


void
on_buttongotomodifliste_clicked        (GtkWidget      *objet,
                                        gpointer         user_data)
{
        GtkWidget *window;
	GtkWidget *window1;
	
	window = lookup_widget(objet,"listes");
	window1 = create_modifierlisteh();
	gtk_widget_destroy(window);
	gtk_widget_show(window1);
       	
	 

}


void
on_buttongotosupprimerliste_clicked    (GtkWidget       *objet,
                                        gpointer         user_data)
{
        GtkWidget *window;
	GtkWidget *window1;
	
	window = lookup_widget(objet,"listes");
	window1 = create_suppliste();
	gtk_widget_destroy(window);
	gtk_widget_show(window1);

}

/****************************************************************************************************************/


void view_popup_menu_onDoSomething(GtkWidget *menuitem, gpointer userdata)
{
	GtkTreeView *treeview = GTK_TREE_VIEW(userdata);
	GtkWidget *fenetre_afficher;
	GtkWidget *fenetre_modif;
	GtkWidget *cin, *nom, *prenom, *jour, *mois, *annee, *email, *tel, *id_bureau, *sexe, *role, *homme, *femme;

	date1 d;
	char jo[20];
	char mo[20];
	char an[20];
	char id[20];
	fenetre_afficher = lookup_widget(treeview, "gestion_utilisateur");
	gtk_widget_destroy(fenetre_afficher);
	user um = update_user(idM);
	d = um.dateN;
	fenetre_modif = create_modif();
	/*cin = lookup_widget(fenetre_modif, "cinp");
        strcpy(id,gtk_entry_get_text(GTK_ENTRY(cin)));
	gtk_entry_set_text(GTK_ENTRY(cin), um.cin);*/
	//gtk_entry_set_editable(cin, FALSE);
	/*nom = lookup_widget(fenetre_modif, "nomp");
	gtk_entry_set_text(GTK_ENTRY(nom), um.nom);
	prenom = lookup_widget(fenetre_modif, "prenomp");
	gtk_entry_set_text(GTK_ENTRY(prenom), um.prenom);
	email = lookup_widget(fenetre_modif, "emailp");
	gtk_entry_set_text(GTK_ENTRY(email), um.email);
	tel = lookup_widget(fenetre_modif, "telp");
	gtk_entry_set_text(GTK_ENTRY(tel), um.tel);
	id_bureau = lookup_widget(fenetre_modif, "id_bureau");
	gtk_entry_set_text(GTK_ENTRY(id_bureau), um.id_bureau);
	jour = lookup_widget(fenetre_modif, "jourp");
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(jour), um.dateN.jour);
	mois = lookup_widget(fenetre_modif, "moisp");
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(mois), um.dateN.mois);
	annee = lookup_widget(fenetre_modif, "anneep");
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(annee), um.dateN.annee);
	role = lookup_widget(fenetre_modif, "rolep");
	int i = test_role(um.role);
	gtk_combo_box_set_active(GTK_COMBO_BOX(role), i);
	homme = lookup_widget(fenetre_modif, "hommep");
	femme = lookup_widget(fenetre_modif, "femmep");
	if (strcmp(um.sexe, "homme") == 0)
	{
		gtk_toggle_button_set_active(GTK_RADIO_BUTTON(homme), TRUE);
		gtk_toggle_button_set_active(GTK_RADIO_BUTTON(femme), FALSE);
	}
	else if (strcmp(um.sexe, "femme") == 0)
	{
		gtk_toggle_button_set_active(GTK_RADIO_BUTTON(homme), FALSE);
		gtk_toggle_button_set_active(GTK_RADIO_BUTTON(femme), TRUE);
	}
*/
	gtk_widget_show(fenetre_modif);
}










void view_popup_menu_onDoSomething1(GtkWidget *menuitem, gpointer userdata)
{
	GtkTreeView *treeview = GTK_TREE_VIEW(userdata);
	supprimer_user(idM);
	GtkWidget *fenetre_afficher,*w2;
	GtkWidget *treeview1;
	w2=lookup_widget(treeview,"gestion_utilisateur");
	fenetre_afficher=create_suppUser();
	gtk_widget_show(fenetre_afficher);
	gtk_widget_destroy(w2);
	/*treeview1=lookup_widget(fenetre_afficher,"treeview1");
	afficher_user(treeview1);*/
}










void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}
/**********************************************************************/
void view_popup_menu(GtkWidget *treeview, GdkEventButton *event, gpointer userdata)
{
	GtkWidget *menu,*menu1, *menuitem,*menuitem1,*menuitem2;
	GtkTreeIter iter;
	GtkTreePath *path;
	menu = gtk_menu_new();
	menuitem = gtk_menu_item_new_with_label("Modifier");
	menuitem1 = gtk_menu_item_new_with_label("Supprimer");

	g_signal_connect(menuitem, "activate",
					 (GCallback)view_popup_menu_onDoSomething, treeview);
	g_signal_connect(menuitem1, "activate",
					 (GCallback)view_popup_menu_onDoSomething1, treeview);
	if (gtk_tree_view_get_path_at_pos(GTK_TREE_VIEW(treeview),
									  (gint)event->x,
									  (gint)event->y,
									  &path, NULL, NULL, NULL))
	{
		GtkTreeModel *model = gtk_tree_view_get_model(treeview);
		gchar *cin;

		if (gtk_tree_model_get_iter(model, &iter, path))
		{

			gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 3, &cin, -1);

			strcpy(idM, cin);
		}
	}

	gtk_menu_shell_append(GTK_MENU_SHELL(menu), menuitem);
	gtk_menu_shell_append(GTK_MENU_SHELL(menu), menuitem1);
	

	gtk_widget_show_all(menu);

	gtk_menu_popup(GTK_MENU(menu), NULL, NULL, NULL, NULL,
				   (event != NULL) ? event->button : 0,
				   gdk_event_get_time((GdkEvent *)event));

}


/**************************************************************************************/


gboolean
on_treeview1_button_press_event        (GtkWidget *treeview, GdkEventButton *event, gpointer userdata)
{

 if (event->type == GDK_BUTTON_PRESS && event->button == 3)
	{

		if (1)
		{
			GtkTreeSelection *selection;

			selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview));

			if (gtk_tree_selection_count_selected_rows(selection) <= 1)
			{
				GtkTreePath *path;

				if (gtk_tree_view_get_path_at_pos(GTK_TREE_VIEW(treeview),
												  (gint)event->x,
												  (gint)event->y,
												  &path, NULL, NULL, NULL))
				{
					gtk_tree_selection_unselect_all(selection);
					gtk_tree_selection_select_path(selection, path);

					gtk_tree_path_free(path);
				}
			}
		}

		view_popup_menu(treeview, event, userdata);

		return TRUE;
	}

	return FALSE;
}
gboolean
on_treeview1_popup_menu                (GtkWidget *treeview, gpointer userdata)
{
  view_popup_menu(treeview, NULL, userdata);

	return TRUE;

}




void
on_radiobuttonhommem_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
        z = 1;
	}

}


void
on_radiobuttonfemmem_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
        z = 1;
	}
}


void
on_buttonconsulterliste_clicked        (GtkWidget      *objet,
                                        gpointer         user_data)
{

	GtkWidget *input1;
	GtkWidget *input2;
	GtkWidget *input3;
	GtkWidget *input4;
	GtkWidget *input5;
	GtkWidget *input6;
	GtkWidget *input7;
	GtkWidget *input8;
	GtkWidget *input9;
	GtkWidget *output;
	GtkWidget *output10;
	GtkWidget *tg1,*tg2;
	char id[20];
	input1=lookup_widget(objet,"entryidlistem");
	strcpy(id,gtk_entry_get_text(GTK_ENTRY(input1)));

	char texte1[200],texte2[200],texte3[200],texte4[200];
	char outputmessage[100];
	
	
	input2=lookup_widget(objet,"entryidpresidentm");
	input3=lookup_widget(objet,"comboboxentryorientationm");
	input4=lookup_widget(objet,"entryprogrammem");
	input5=lookup_widget(objet,"entrynompresidentm");
	input9=lookup_widget(objet,"entryprenompresidentm");
	input6=lookup_widget(objet,"spinbuttonjourm");
	input7=lookup_widget(objet,"spinbuttonmoism");
	input8=lookup_widget(objet,"spinbuttonanneem");
	output = lookup_widget(objet,"labelidlistem");
	
	
	if(idExist(id)==0){
		
		sprintf(outputmessage,"Cette liste n'existe pas\n");
		GdkColor color;
		gdk_color_parse ("#ff250d", &color);
		gtk_widget_modify_fg (output10, GTK_STATE_NORMAL, &color);
    		gtk_label_set_text(GTK_LABEL(output),outputmessage);		
	}
	
	else{
		gtk_label_set_text(GTK_LABEL(output),"✔️ \n Cette liste existe");
		liste c;
		strcpy(c.idpresidentliste,find_liste(id).idpresidentliste);
		strcpy(c.nompresident,find_liste(id).nompresident);
		strcpy(c.prenompresident,find_liste(id).prenompresident);
		strcpy(c.orinetation,find_liste(id).orinetation);
		strcpy(c.programmeelectorale,find_liste(id).programmeelectorale);
		gtk_spin_button_set_value(GTK_SPIN_BUTTON(input6), find_liste(id).jourcliste);
		gtk_spin_button_set_value(GTK_SPIN_BUTTON(input7), find_liste(id).moiscliste);
		gtk_spin_button_set_value(GTK_SPIN_BUTTON(input8), find_liste(id).anneecliste);
		strcpy(c.sexe,find_liste(id).sexe);
		tg1=lookup_widget(objet,"radiobuttonhommem");
		tg2=lookup_widget(objet,"radiobuttonfemmem");
		if(strcmp(c.sexe,"homme")==0){gtk_toggle_button_set_active(GTK_RADIO_BUTTON (tg1),TRUE);}
		if(strcmp(c.sexe,"femme")==0){gtk_toggle_button_set_active(GTK_RADIO_BUTTON (tg2),TRUE);}
		

		sprintf(texte1,"%s",c.idpresidentliste);
    		gtk_entry_set_text(GTK_ENTRY(input2),texte1);

		sprintf(texte2,"%s",c.nompresident);
    		gtk_entry_set_text(GTK_ENTRY(input5),texte2);
		
		sprintf(texte3,"%s",c.prenompresident);
    		gtk_entry_set_text(GTK_ENTRY(input9),texte3);

		sprintf(texte4,"%s",c.programmeelectorale);
    		gtk_entry_set_text(GTK_ENTRY(input4),texte4);
		
		
		int i = test_orientation(find_liste(id).orinetation);
		gtk_combo_box_set_active(GTK_COMBO_BOX(input3), i);

		sprintf(outputmessage,"Cette liste existe\n Voici ses caractéristiques\n");
		output10 = lookup_widget(objet,"labelmodif");
		GdkColor color;
		gdk_color_parse ("#0c8ae8", &color);
		gtk_widget_modify_fg (output10, GTK_STATE_NORMAL, &color);
    		gtk_label_set_text(GTK_LABEL(output10),outputmessage);

}

}


void
on_backmodifliste_clicked              (GtkWidget      *objet,
                                        gpointer         user_data)
{
        GtkWidget *window;
	GtkWidget *window1;
	GtkWidget *treeview;
	window = lookup_widget(objet,"modifierlisteh");
	window1 = create_listes ();
	gtk_widget_destroy(window);
	gtk_widget_show(window1);	
	treeview = lookup_widget(window1,"treeviewlistes");	
	afficher_liste(treeview);
}


void
on_modifierliste_clicked               (GtkWidget      *objet,
                                        gpointer         user_data)
{
        GtkWidget *input1;
	GtkWidget *input2;
	GtkWidget *input3;
	GtkWidget *input4;
	GtkWidget *input5;
	GtkWidget *input6;
	GtkWidget *input7;
	GtkWidget *input8;
	GtkWidget *input9;
	GtkWidget *output;
	GtkWidget *output1;
	GtkWidget *output10,*vote;

	
	int p;

	char texte[200];
	char outputmessage[100];

	liste c;

	input1=lookup_widget(objet,"entryidlistem");
	input2=lookup_widget(objet,"entryidpresidentm");
	input3=lookup_widget(objet,"comboboxentryorientationm");
	input4=lookup_widget(objet,"entryprogrammem");
	input5=lookup_widget(objet,"entrynompresidentm");
	input9=lookup_widget(objet,"entryprenompresidentm");
	input6=lookup_widget(objet,"spinbuttonjourm");
	input7=lookup_widget(objet,"spinbuttonmoism");
	input8=lookup_widget(objet,"spinbuttonanneem");
	
	


	if (z== 1){
		strcpy(c.sexe,"homme");
	}
	else if(z== 2){
		strcpy(c.sexe,"femme");
	}
	

	
	
	strcpy(c.idliste,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(c.idpresidentliste,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(c.orinetation,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input3)));
	strcpy(c.programmeelectorale,gtk_entry_get_text(GTK_ENTRY(input4)));
	strcpy(c.nompresident,gtk_entry_get_text(GTK_ENTRY(input5)));
	strcpy(c.prenompresident,gtk_entry_get_text(GTK_ENTRY(input9)));
	c.jourcliste=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input6));
	c.moiscliste=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input7));
	c.anneecliste=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input8));
	vote = lookup_widget(objet,"vote");
	if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(vote))) {strcpy(c.vote,"⭐");}else{strcpy(c.vote,"⛔");}
		sprintf(outputmessage,"Liste Sauvegardée Avec Succés\n");
		output10 = lookup_widget(objet,"labelmodifh");
		GdkColor color;
		gdk_color_parse ("#0c8ae8", &color);
		gtk_widget_modify_fg (output10, GTK_STATE_NORMAL, &color);
    		gtk_label_set_text(GTK_LABEL(output10),outputmessage);
	        modifier_liste(c);

}


void
on_buttonsupprimerliste_clicked        (GtkWidget      *objet,
                                        gpointer         user_data)
{
	GtkWidget *input;
	GtkWidget *output;
	char id[200];
	char texte[100];

	input = lookup_widget(objet,"entry12");
	strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));
	
	if(idExist(id)){
		supprimer_liste(id);		
		sprintf(texte,"Votre suppression à été effectué avec succés\n");
		output = lookup_widget(objet,"labelsuppliste");
		GdkColor color;
		gdk_color_parse ("#40e61a", &color);
		gtk_widget_modify_fg (output, GTK_STATE_NORMAL, &color);
    		gtk_label_set_text(GTK_LABEL(output),texte);
		
		
	}
	else{
		sprintf(texte,"Cett liste n'existe pas\n");
		output = lookup_widget(objet,"labelsuppliste");
		GdkColor color;
		gdk_color_parse ("#ff250d", &color);
		gtk_widget_modify_fg (output, GTK_STATE_NORMAL, &color);
    		gtk_label_set_text(GTK_LABEL(output),texte);	
	} 

}


void
on_buttonbacksuppliste_clicked         (GtkWidget      *objet,
                                        gpointer         user_data)
{
        GtkWidget *window;
	GtkWidget *window1;
	GtkWidget *treeview;
	window = lookup_widget(objet,"suppliste");
	window1 = create_listes ();
	gtk_widget_destroy(window);
	gtk_widget_show(window1);	
	treeview = lookup_widget(window1,"treeviewlistes");	
	afficher_liste(treeview);

}

/**********************************************************************/
void
on_radiobuttonvb_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}





/**********************************************************************/
void
on_buttonobset_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
float t,e;

char msg2[50];

GtkWidget *output2;
obs(&t,&e) ;

output2=lookup_widget(button,"labelobset");
gtk_label_set_text(GTK_LABEL(output2),"");

sprintf(msg2,"le taux des observateurs etrangers est %.2f  ./.",e);

gtk_label_set_text(GTK_LABEL(output2),msg2);

}


void
on_buttonobstn_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{float t,e;
char msg[50];

GtkWidget *output;

obs(&t,&e) ;




output=lookup_widget(button,"labelobstn");
gtk_label_set_text(GTK_LABEL(output),"");

sprintf(msg,"le taux des observateurs tunisiens est %.2f  ./.",t);

gtk_label_set_text(GTK_LABEL(output),msg);

}


void
on_Actualise_tree_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
  GtkWidget *gestion_election;
   GtkWidget *w1;
   GtkWidget *treeviewfarah;

   w1=lookup_widget(button,"gestion_election");
   gestion_election=create_gestion_election();
   gtk_widget_show(gestion_election);
   gtk_widget_hide(w1);
   treeviewfarah=lookup_widget(gestion_election,"treeviewfarah");
   afficher_elections(treeviewfarah);

}

int choixfarah[]={0,0,0};
void
on_checkbutton_rech1_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
 if(gtk_toggle_button_get_active(togglebutton))
  choixfarah[0]=1;

}


void
on_checkbutton_rech2_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
 if(gtk_toggle_button_get_active(togglebutton))
  choixfarah[1]=1;

}


void
on_checkbutton_rech3_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
 if(gtk_toggle_button_get_active(togglebutton))
  choixfarah[2]=1;

}


void
on_valide_rech_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
 GtkWidget *gestion_election;
 GtkWidget *chercher_election;
 GtkWidget *treeview1;
 if(choixfarah[0]==1){

     gestion_election=lookup_widget(button,"gestion_election");
     gtk_widget_destroy(gestion_election);
     chercher_election=lookup_widget(button,"gestion_election");
     chercher_election=create_gestion_election();
     gtk_widget_show(chercher_election);
     treeview1=lookup_widget(chercher_election,"treeviewfarah");
     rechercher_mahdia(treeview1);}
  
  else if(choixfarah[1]==1){
   gestion_election=lookup_widget(button,"gestion_election");
   gtk_widget_destroy(gestion_election);
   chercher_election=lookup_widget(button,"gestion_election");
   chercher_election=create_gestion_election();
   gtk_widget_show(chercher_election);
   treeview1=lookup_widget(chercher_election,"treeviewfarah");
   rechercher_sfax(treeview1);}
     
   else if(choixfarah[2]==1){
 gestion_election=lookup_widget(button,"gestion_election");
 gtk_widget_destroy(gestion_election);
 chercher_election=lookup_widget(button,"gestion_election");
 chercher_election=create_gestion_election();
 gtk_widget_show(chercher_election);
 treeview1=lookup_widget(chercher_election,"treeviewfarah");
 rechercher_tunis(treeview1);}

}


void
on_valider_tache_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
 GtkWidget *output,*output1,*output2;
 float taux1;
 float f,h;
 char taux_femme[50],taux_homme[50],taux_election[50];
 
 output=lookup_widget(button,"taux_electeur");
 output1=lookup_widget(button,"taux_femme");
 output2=lookup_widget(button,"taux_homme");

 taux1=TPE("utilisateur.txt");
  TPHF(&f,&h);

 sprintf(taux_femme,"%.2f  %%",f);
 sprintf(taux_homme,"%.2f  %%",h);
 sprintf(taux_election,"%.2f  %%",taux1);

 gtk_label_set_text(GTK_LABEL(output),taux_election);
 gtk_label_set_text(GTK_LABEL(output1),taux_femme);
 gtk_label_set_text(GTK_LABEL(output2),taux_homme);

}


void
on_buttonconfirmervote_clicked         (GtkWidget       *objet,
                                        gpointer         user_data)
{
	user u;
	vote V;
	FILE *f1;
	FILE *f2; 
	f1 = fopen("utilisateur.txt","a");
	f2 = fopen("vote.txt","r");
 	GtkWidget *input0;
	GtkWidget *input1;
	GtkWidget *input2;
	GtkWidget *input3;
	GtkWidget *input4;
	GtkWidget *ajoutervote;
        GtkWidget *afficherlistes;
	GtkWidget *treeview3;

        input0=lookup_widget(objet,"cinv");
	input1=lookup_widget(objet,"entryidvhh");
	input2=lookup_widget(objet,"entryevhh");
	input3=lookup_widget(objet,"entrylvhh");
	input4=lookup_widget(objet,"voteblancahh");
	strcpy(V.cin,gtk_entry_get_text(GTK_ENTRY(input0)));
	strcpy(V.id_vote,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(V.id_election,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(V.id_liste,gtk_entry_get_text(GTK_ENTRY(input3)));
	char ch5[20],ch4[20];
        strcpy(ch5,"vote_blanc");strcpy(ch4,"vote_identifié");
	if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(input4))) {strcpy(V.vote_blanc,ch5);}else{strcpy(V.vote_blanc,ch4);}
	
	
	while(fscanf(f1,"%s %s %s %s %d/%d/%d %s %s %s %s %s %s\n",u.cin,u.nom,u.prenom,u.id_bureau,&u.dateN.jour,&u.dateN.mois,&u.dateN.annee,u.email,u.tel,u.role,u.sexe,u.vote,u.password) != EOF 		&& fscanf(f2,"%s %s %s %s %s\n",V.cin,V.id_vote,V.id_election,V.id_liste,V.vote_blanc)  !=EOF){

   		if(strcmp(u.cin,V.cin)==0 && gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(input4)))
		{strcpy(u.vote,V.vote_blanc);}
                if (strcmp(u.cin,V.cin)==0 && !(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(input4))))
		{strcpy(u.vote,V.id_liste);}

}
	ajouter_vote(V);
	ajoutervote=lookup_widget(objet,"ajout_vote");
	gtk_widget_destroy(ajoutervote);
        afficherlistes=create_gestion_vote();
        gtk_widget_show(afficherlistes);
        treeview3=lookup_widget(afficherlistes,"treeview3");
        affichervote(treeview3);
}



void
on_espace_admin_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *fenetre_acceuil;
GtkWidget *fenetre_afficher;

fenetre_afficher=lookup_widget(objet,"acceuil_seconde");
gtk_widget_destroy(fenetre_afficher);
fenetre_acceuil=lookup_widget(objet,"acceuil");
fenetre_acceuil=create_acceuil();
gtk_widget_show(fenetre_acceuil);
///////////////////////////////////////
/*
user u;
char texte[100];
GtkWidget *output;
GtkWidget *fenetre_afficher,*w1;
w1=lookup_widget(objet,"acceuil_seconde");
fenetre_afficher=create_acceuil();
FILE *f;
f=fopen("utilisateur.txt","r");
fscanf(f,"%s %s %s %s %d/%d/%d %s %s %s %s %s %s\n",u.cin,u.nom,u.prenom,u.id_bureau,&u.dateN.jour,&u.dateN.mois,&u.dateN.annee,u.email,u.tel,u.role,u.sexe,u.vote,u.password);
if(strcmp("ADMIN",u.role)==0){
gtk_widget_show(fenetre_afficher);
gtk_widget_destroy(w1);
}
else{
		output = lookup_widget(objet,"messageacceuils");
		GdkColor color;
		gdk_color_parse ("#ff250d", &color);
		gtk_widget_modify_fg (output, GTK_STATE_NORMAL, &color);
		gtk_label_set_markup (GTK_LABEL (output), "<b>Accées Refusé</b>");

}
*/
}


void
on_espace_electeur_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *output1;
GtkWidget *fenetre_afficher1,*w2;
w2=lookup_widget(objet,"acceuil_seconde");
fenetre_afficher1=create_acceuil_ges_liste();
gtk_widget_show(fenetre_afficher1);
gtk_widget_destroy(w2);

	/*user u;
	char texte[100];
	GtkWidget *output;
	GtkWidget *window;
	GtkWidget *window2;
	window = lookup_widget(objet,"acceuil_seconde");
	window2 =create_acceuil_ges_liste();
	FILE *f;
	f=fopen("utilisateur.txt","r");
	fscanf(f,"%s %s %s %s %d/%d/%d %s %s %s %s %s %s\n",u.cin,u.nom,u.prenom,u.id_bureau,&u.dateN.jour,&u.dateN.mois,&u.dateN.annee,u.email,u.tel,u.role,u.sexe,u.vote,u.password);
	if(strcmp("electeur",u.role)==0 ){
	gtk_widget_destroy(window);
	gtk_widget_show(window2);	
	}
	else{
		output = lookup_widget(objet,"messageacceuils");
		GdkColor color;
		gdk_color_parse ("#ff250d", &color);
		gtk_widget_modify_fg (output, GTK_STATE_NORMAL, &color);
		gtk_label_set_markup (GTK_LABEL (output), "<b>Accées Refusé</b>");
}*/


}
void
on_espace_agent_clicked                (GtkWidget        *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_afficher,*w1;
GtkWidget *treeview2;
w1=lookup_widget(objet,"acceuil_seconde");
fenetre_afficher=create_gestion_observateur();
gtk_widget_show(fenetre_afficher);
gtk_widget_destroy(w1);
treeview2=lookup_widget(fenetre_afficher,"treeview2");
afficher_observateur(treeview2);
/****************************************************/
/*
user u;
char texte[100];
GtkWidget *output;
GtkWidget *fenetre_afficher,*w1;
w1=lookup_widget(objet,"acceuil_seconde");
fenetre_afficher=create_gestion_observateur();
FILE *f;
f=fopen("utilisateur.txt","r");
fscanf(f,"%s %s %s %s %d/%d/%d %s %s %s %s %s %s\n",u.cin,u.nom,u.prenom,u.id_bureau,&u.dateN.jour,&u.dateN.mois,&u.dateN.annee,u.email,u.tel,u.role,u.sexe,u.vote,u.password);
if(strcmp("AGENT-de-bureau",u.role)==0){
gtk_widget_show(fenetre_afficher);
gtk_widget_destroy(w1);
}
else{
		output = lookup_widget(objet,"messageacceuils");
		GdkColor color;
		gdk_color_parse ("#ff250d", &color);
		gtk_widget_modify_fg (output, GTK_STATE_NORMAL, &color);
		gtk_label_set_markup (GTK_LABEL (output), "<b>Accées Refusé</b>");

}

*/
}


void
on_ajoutvotehs1_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout;
GtkWidget *fenetre_afficher;

fenetre_afficher=lookup_widget(objet,"acceuil_ges_liste");
gtk_widget_destroy(fenetre_afficher);
fenetre_ajout=lookup_widget(objet,"ajout_vote");
fenetre_ajout=create_ajout_vote();
gtk_widget_show(fenetre_ajout);
}


void
on_liste_elecths_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *fenetre_afficher,*w1;
GtkWidget *treeviewlistes;
w1=lookup_widget(objet,"acceuil_ges_liste");
fenetre_afficher=create_listes();
gtk_widget_show(fenetre_afficher);
gtk_widget_destroy(w1);
treeviewlistes=lookup_widget(fenetre_afficher,"treeviewlistes");
afficher_liste(treeviewlistes);
}



void
on_backvote_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_modif;
GtkWidget *fenetre_afficher;
fenetre_modif=lookup_widget(objet,"ajout_vote");
gtk_widget_destroy(fenetre_modif);
fenetre_afficher=create_acceuil_ges_liste();
gtk_widget_show(fenetre_afficher);

}



void
on_backliste1_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_modif;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;
fenetre_modif=lookup_widget(objet,"gestion_election");
gtk_widget_destroy(fenetre_modif);

fenetre_afficher=create_acceuil_seconde();
gtk_widget_show(fenetre_afficher);
}


void
on_quit_vote7_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
   	GtkWidget *winmen;
    	winmen=lookup_widget(button,"gestion_vote");
    	gtk_widget_destroy(winmen);
}


void
on_retour_vote4_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_modif;
GtkWidget *fenetre_afficher;
fenetre_modif=lookup_widget(objet,"gestion_vote");
gtk_widget_destroy(fenetre_modif);
fenetre_afficher=create_acceuil_ges_liste();
gtk_widget_show(fenetre_afficher);
}


void
on_buttontauxvoteblanc_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
float t;
char msg[50];

GtkWidget *output;

blanc(&t) ;




output=lookup_widget(button,"labelvoteblanc");
gtk_label_set_text(GTK_LABEL(output),"");

sprintf(msg,"le taux des votes blanc %.2f  ./.",t);

gtk_label_set_text(GTK_LABEL(output),msg);

}

int idmod;
void
on_modifier_observateur1_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Nom, *Prenom, *Nationalite, *jour, *mois, *annee,*ID,*sortie;
char ide[20];
int iden;
char id[20];
observateur nouv;
observateur o;


ID=lookup_widget(GTK_WIDGET(button),"idm");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(ID)));
Nom=lookup_widget(GTK_WIDGET(button),"nomm");
Prenom=lookup_widget(GTK_WIDGET(button),"prenomm");
jour=lookup_widget(GTK_WIDGET(button),"jourm");
mois=lookup_widget(GTK_WIDGET(button),"moism");
annee=lookup_widget(GTK_WIDGET(button),"anneem");
Nationalite=lookup_widget(GTK_WIDGET(button),"nationalitem");
sortie=lookup_widget(GTK_WIDGET(button),"label496");
nouv.date_naissance.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
nouv.date_naissance.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
nouv.date_naissance.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));
strcpy(nouv.nationalite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Nationalite)));
strcpy(nouv.nom,gtk_entry_get_text(GTK_ENTRY(Nom)));
strcpy(nouv.prenom,gtk_entry_get_text(GTK_ENTRY(Prenom)));
professions(profession,nouv.profession);
iden=atoi(id);
genres(genre,nouv.genre);
o=chercher(iden,"observateur.txt");

if (o.id==-1)
	gtk_label_set_text(GTK_LABEL(sortie)," votre id n'existe pas !");
else{
        
	nouv.id=idmod;
	int x;
	x=modifier(idmod, nouv, "observateur.txt");

	GtkWidget *modif, *liste, *treeview;

	modif=lookup_widget(GTK_WIDGET(button),"Modifier_observateur");

	gtk_widget_destroy(modif);

	liste=lookup_widget(GTK_WIDGET(button),"gestion_observateur");

	liste=create_gestion_observateur();

	gtk_widget_show(liste);

	treeview=lookup_widget(liste,"treeview2");

	afficher_observateur(treeview);}

}


void
on_modifobs9_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_modif;
GtkWidget *fenetre_afficher;

fenetre_afficher=lookup_widget(objet,"gestion_observateur");

gtk_widget_destroy(fenetre_afficher);
fenetre_modif=lookup_widget(objet,"Modifier_observateur");
fenetre_modif=create_modifier_observateur();
gtk_widget_show(fenetre_modif);
}


void
on_backacceuil2_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_retour_modifobs1_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}

