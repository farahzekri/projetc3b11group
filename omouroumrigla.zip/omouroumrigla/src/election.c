#include <stdio.h>
#include <string.h>
#include "election.h"

#include <gtk/gtk.h>
enum
   { 
       
       ID,
       DATE,
       VILLE,
       MUNICIPALITE,
       NB_HABITANT,
       NB_CONSEILLE,
       COLUMNS,
   };

void ajouter_elections(GestionElection E)
{
   FILE *f=fopen("election.txt","a+");
   if(f!=NULL)
    {
      if(strcmp(E.nb_habitant,"5.000")==0)

          strcpy(E.nb_conseille,"10");
      else if(strcmp(E.nb_habitant,"5.001a10.000")==0)
          strcpy(E.nb_conseille,"12");

      else if(strcmp(E.nb_habitant,"10.001a25.000")==0)
           strcpy(E.nb_conseille,"16");

      else if(strcmp(E.nb_habitant,"25.001a50.000")==0)
           strcpy(E.nb_conseille,"22");

     else if(strcmp(E.nb_habitant,"50.001a100.000")==0)
           strcpy(E.nb_conseille,"30");

     else if(strcmp(E.nb_habitant,"100.001a500.000")==0)
           strcpy(E.nb_conseille,"40");
   
     else if(strcmp(E.nb_habitant,"plus500.000")==0)
           strcpy(E.nb_conseille,"60");
     
      
       fprintf(f,"%s %d %d %d %s %s %s %s\n",E.id,E.date_election.jour,E.date_election.mois,E.date_election.annee,
                                      E.ville,E.municipalite,E.nb_habitant,E.nb_conseille);
       }
  fclose(f);
}


void supprimer_elections(char idele[])
{

  GestionElection E;
   FILE *f=fopen("election.txt","r");
   FILE *f2=fopen("nouv.txt","a");

       while(fscanf(f,"%s %d %d %d %s %s %s %s\n",E.id,&E.date_election.jour,&E.date_election.mois,&E.date_election.annee,
                                      E.ville,E.municipalite,E.nb_habitant,E.nb_conseille)!=EOF)
          {
            if ((strcmp(E.id,idele)!=0))
                 
                fprintf(f2,"%s %d %d %d %s %s %s %s\n",E.id,E.date_election.jour,E.date_election.mois,E.date_election.annee,
                                      E.ville,E.municipalite,E.nb_habitant,E.nb_conseille);
             
         }
 
   fclose(f);
   fclose(f2);
   remove("election.txt");
   rename("nouv.txt","election.txt");
 
}

void afficher_elections(GtkWidget *liste)
{
   GtkCellRenderer *renderer;
   GtkTreeViewColumn *column;
   GtkTreeIter iter;
   GtkListStore *store;
  
    
    
    char j[10];
    char m[10];
    char ann[10];

    char id[19];
    char date_election[40];
    char ville[20];
    char municipalite[50];
    char nb_habitant[50];
    char nb_conseille[50];
    char dateele[50];
    
    
    store=NULL;
    FILE *f;

    store=gtk_tree_view_get_model(liste);
    if(store==NULL)
    {

      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",ID,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("date_election",renderer,"text",DATE,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("ville",renderer,"text",VILLE,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("municipalite",renderer,"text",MUNICIPALITE,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("nb_habitant",renderer,"text",NB_HABITANT,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("nb_conseille",renderer,"text",NB_CONSEILLE,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

      

      store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
   
       f=fopen("election.txt","r");
      if(f==NULL){
        return ;}
      
       else {
          f=fopen("election.txt","a+");
             while(fscanf(f,"%s %s %s %s %s %s %s %s \n",id,j,m,ann,ville,municipalite,nb_habitant,nb_conseille)!=EOF)
           {
 	      strcpy(date_election, strcat(strcat(strcat(strcat(j,"/"),m),"/"),ann));
              //sprintf(date_election,"%d/%d/%d",j,m,ann);

             
             gtk_list_store_append(store,&iter);
             gtk_list_store_set (store,&iter,ID,id,DATE,date_election,VILLE,ville,MUNICIPALITE,municipalite,NB_HABITANT,
                                      nb_habitant,NB_CONSEILLE,nb_conseille,-1);
            }
           fclose(f);
         
           gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL (store));
           g_object_unref(store);
         }
       
}}

void modifier_elections(GestionElection E1)
{
   GestionElection E;
   FILE *f=fopen("election.txt","r");
   FILE *f2=fopen("nouv.txt","a");
  
    while(fscanf(f,"%s %d %d %d %s %s %s %s\n",E.id,&E.date_election.jour,&E.date_election.mois,&E.date_election.annee,
                                      E.ville,E.municipalite,E.nb_habitant,E.nb_conseille)!=EOF)
      {
         if(strcmp(E.id,E1.id)==0){
                       if(strcmp(E1.nb_habitant,"5.000")==0)

                         	strcpy(E1.nb_conseille,"10");
      	             else if(strcmp(E1.nb_habitant,"5.001a10.000")==0)
          			strcpy(E1.nb_conseille,"12");

      		    else if(strcmp(E1.nb_habitant,"10.001a25.000")==0)
           			strcpy(E1.nb_conseille,"16");

      		    else if(strcmp(E1.nb_habitant,"25.001a50.000")==0)
           			strcpy(E1.nb_conseille,"22");

     	          else if(strcmp(E1.nb_habitant,"50.001a100.000")==0)
           			strcpy(E1.nb_conseille,"30");

     		else if(strcmp(E1.nb_habitant,"100.001a500.000")==0)
          			 strcpy(E1.nb_conseille,"40");
   
     		else if(strcmp(E1.nb_habitant,"plus500.000")==0)
          			 strcpy(E1.nb_conseille,"60");
                 fprintf(f2,"%s %d %d %d %s %s %s %s\n",E1.id,E1.date_election.jour,E1.date_election.mois,E1.date_election.annee,
                                      E1.ville,E1.municipalite,E1.nb_habitant,E1.nb_conseille);
             //E=E1;
            }
            
          else{
                       if(strcmp(E.nb_habitant,"5.000")==0)

                         	strcpy(E.nb_conseille,"10");
      	             else if(strcmp(E.nb_habitant,"5.001a10.000")==0)
          			strcpy(E.nb_conseille,"12");

      		    else if(strcmp(E.nb_habitant,"10.001a25.000")==0)
           			strcpy(E.nb_conseille,"16");

      		    else if(strcmp(E.nb_habitant,"25.001a50.000")==0)
           			strcpy(E.nb_conseille,"22");

     	          else if(strcmp(E.nb_habitant,"50.001a100.000")==0)
           			strcpy(E.nb_conseille,"30");

     		else if(strcmp(E.nb_habitant,"100.001a500.000")==0)
          			 strcpy(E.nb_conseille,"40");
   
     		else if(strcmp(E.nb_habitant,"plus500.000")==0)
          			 strcpy(E.nb_conseille,"60");
           fprintf(f2,"%s %d %d %d %s %s %s %s\n",E.id,E.date_election.jour,E.date_election.mois,E.date_election.annee,
                                      E.ville,E.municipalite,E.nb_habitant,E.nb_conseille);}
     }
 
     fclose(f);
     fclose(f2);
     remove("election.txt");
     rename("nouv.txt","election.txt");
     
    
}

void rechercher_elections(GtkWidget *liste,char rechele[]){
   GtkCellRenderer *renderer;
   GtkTreeViewColumn *column;
   GtkTreeIter iter;
   GtkListStore *store;
  
    
    
    char j[10];
    char m[10];
    char ann[10];

    char id[19];
    char date_election[40];
    char ville[20];
    char municipalite[50];
    char nb_habitant[50];
    char nb_conseille[50];
    char dateele[50];
    
    
    store=NULL;
    FILE *f;

    store=gtk_tree_view_get_model(liste);
    if(store==NULL)
    {

      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",ID,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("date_election",renderer,"text",DATE,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("ville",renderer,"text",VILLE,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("municipalite",renderer,"text",MUNICIPALITE,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("nb_habitant",renderer,"text",NB_HABITANT,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("nb_conseille",renderer,"text",NB_CONSEILLE,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

      

      store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
   
       f=fopen("election.txt","r");
      if(f==NULL){
        return ;}
      
       else {
          f=fopen("election.txt","a+");
             while(fscanf(f,"%s %s %s %s %s %s %s %s \n",id,j,m,ann,ville,municipalite,nb_habitant,nb_conseille)!=EOF)
           {
              if(strcmp(rechele,id)==0){
 	      strcpy(date_election, strcat(strcat(strcat(strcat(j,"/"),m),"/"),ann) );
              //sprintf(date_election,"%d/%d/%d",j,m,ann);
             gtk_list_store_append(store,&iter);
             gtk_list_store_set (store,&iter,ID,id,DATE,date_election,VILLE,ville,MUNICIPALITE,municipalite,NB_HABITANT,
                                      nb_habitant,NB_CONSEILLE,nb_conseille,-1);}
            }
           fclose(f);
         
           gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL (store));
           g_object_unref(store);}}}
void rechercher_tunis(GtkWidget *liste){
   GtkCellRenderer *renderer;
   GtkTreeViewColumn *column;
   GtkTreeIter iter;
   GtkListStore *store;
  
    
    
    char j[10];
    char m[10];
    char ann[10];

    char id[19];
    char date_election[40];
    char ville[20];
    char municipalite[50];
    char nb_habitant[50];
    char nb_conseille[50];
    char dateele[50];
    
    
    store=NULL;
    FILE *f;

    store=gtk_tree_view_get_model(liste);
    if(store==NULL)
    {

      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",ID,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("date_election",renderer,"text",DATE,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("ville",renderer,"text",VILLE,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("municipalite",renderer,"text",MUNICIPALITE,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("nb_habitant",renderer,"text",NB_HABITANT,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("nb_conseille",renderer,"text",NB_CONSEILLE,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

      

      store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
   
       f=fopen("election.txt","r");
      if(f==NULL){
        return ;}
      
       else {
          f=fopen("election.txt","a+");
             while(fscanf(f,"%s %s %s %s %s %s %s %s \n",id,j,m,ann,ville,municipalite,nb_habitant,nb_conseille)!=EOF)
           {
              if(strcmp(ville,"tunis")==0){
 	      strcpy(date_election, strcat(strcat(strcat(strcat(j,"/"),m),"/"),ann) );
              //sprintf(date_election,"%d/%d/%d",j,m,ann);
             gtk_list_store_append(store,&iter);
             gtk_list_store_set (store,&iter,ID,id,DATE,date_election,VILLE,ville,MUNICIPALITE,municipalite,NB_HABITANT,
                                      nb_habitant,NB_CONSEILLE,nb_conseille,-1);}
            }
           fclose(f);
         
           gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL (store));
           g_object_unref(store);}}}
   void rechercher_sfax(GtkWidget *liste){
   GtkCellRenderer *renderer;
   GtkTreeViewColumn *column;
   GtkTreeIter iter;
   GtkListStore *store;
  
    
    
    char j[10];
    char m[10];
    char ann[10];

    char id[19];
    char date_election[40];
    char ville[20];
    char municipalite[50];
    char nb_habitant[50];
    char nb_conseille[50];
    char dateele[50];
    
    
    store=NULL;
    FILE *f;

    store=gtk_tree_view_get_model(liste);
    if(store==NULL)
    {

      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",ID,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("date_election",renderer,"text",DATE,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("ville",renderer,"text",VILLE,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("municipalite",renderer,"text",MUNICIPALITE,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("nb_habitant",renderer,"text",NB_HABITANT,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("nb_conseille",renderer,"text",NB_CONSEILLE,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

      

      store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
   
       f=fopen("election.txt","r");
      if(f==NULL){
        return ;}
      
       else {
          f=fopen("election.txt","a+");
             while(fscanf(f,"%s %s %s %s %s %s %s %s \n",id,j,m,ann,ville,municipalite,nb_habitant,nb_conseille)!=EOF)
           {
              if(strcmp(ville,"sfax")==0){
 	      strcpy(date_election, strcat(strcat(strcat(strcat(j,"/"),m),"/"),ann) );
              //sprintf(date_election,"%d/%d/%d",j,m,ann);
             gtk_list_store_append(store,&iter);
             gtk_list_store_set (store,&iter,ID,id,DATE,date_election,VILLE,ville,MUNICIPALITE,municipalite,NB_HABITANT,
                                      nb_habitant,NB_CONSEILLE,nb_conseille,-1);}
            }
           fclose(f);
         
           gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL (store));
           g_object_unref(store);}}}

void rechercher_mahdia(GtkWidget *liste){
   GtkCellRenderer *renderer;
   GtkTreeViewColumn *column;
   GtkTreeIter iter;
   GtkListStore *store;
  
    
    
    char j[10];
    char m[10];
    char ann[10];

    char id[19];
    char date_election[40];
    char ville[20];
    char municipalite[50];
    char nb_habitant[50];
    char nb_conseille[50];
    char dateele[50];
    
    
    store=NULL;
    FILE *f;

    store=gtk_tree_view_get_model(liste);
    if(store==NULL)
    {

      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",ID,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("date_election",renderer,"text",DATE,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("ville",renderer,"text",VILLE,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("municipalite",renderer,"text",MUNICIPALITE,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("nb_habitant",renderer,"text",NB_HABITANT,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
      renderer=gtk_cell_renderer_text_new();
      column=gtk_tree_view_column_new_with_attributes("nb_conseille",renderer,"text",NB_CONSEILLE,NULL);
      gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

      

      store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
   
       f=fopen("election.txt","r");
      if(f==NULL){
        return ;}
      
       else {
          f=fopen("election.txt","a+");
             while(fscanf(f,"%s %s %s %s %s %s %s %s \n",id,j,m,ann,ville,municipalite,nb_habitant,nb_conseille)!=EOF)
           {
              if(strcmp(ville,"mahdia")==0){
 	      strcpy(date_election, strcat(strcat(strcat(strcat(j,"/"),m),"/"),ann) );
              //sprintf(date_election,"%d/%d/%d",j,m,ann);
             gtk_list_store_append(store,&iter);
             gtk_list_store_set (store,&iter,ID,id,DATE,date_election,VILLE,ville,MUNICIPALITE,municipalite,NB_HABITANT,
                                      nb_habitant,NB_CONSEILLE,nb_conseille,-1);}
            }
           fclose(f);
         
           gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL (store));
           g_object_unref(store);}}}

int control_id(char id[]){

    GestionElection E;
    int x=0;
     
      FILE *f=fopen("election.txt","r");

       while(fscanf(f,"%s %d %d %d %s %s %s %s\n",E.id,&E.date_election.jour,&E.date_election.mois,&E.date_election.annee,
                                      E.ville,E.municipalite,E.nb_habitant,E.nb_conseille)!=EOF)
          {
            if ((strcmp(E.id,id)==0))
                 
              x=1;
             
         }
 
   fclose(f);
 return x;
}
