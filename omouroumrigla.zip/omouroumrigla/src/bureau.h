#ifndef BUREAU_H_INCLUDED
#define BUREAU_H_INCLUDED

#include <stdio.h>
#include<gtk/gtk.h>
typedef struct{
     char id_br[30];
     char id_agent[30];
     char sexe[30];
     char role[30];
     char ville[30];
     char ecole [30];
     char cap_elec[30];
     char cap_obs[30];
     int n_salle;
     
     
}bureau;

/*typedef struct
{
int jour;
int mois;
int annee;
}date1;

typedef struct
{char cin[20];
char nom[20];
char prenom[20];
char password[30];
date1 dateN;
char email[50];
char tel[20];
char role[20];
 char sexe[20];
char  id_bureau[20];
char vote[20];
}user;*/

void ajouter_br(bureau b );
void supprimer_br(char idb[]);
void modifier_bureau(bureau b1 );
int test_capelec(char cap_elec[]);
int test_capob(char cap_obs[]);
int test_ville(char ville[]);
int test_ecole(char ecole[]);
void afficher_bureau(GtkWidget *liste);
void viderbr(GtkWidget *liste);
void rechercher_bureau(GtkWidget *liste,char rechbr[]);
bureau find_br(char id[]);
int verifier_idbr(char id_br[]);
void supprimer_bureau(bureau b);
void rechercher_tunis_yes(GtkWidget *liste);
void rechercher_mahdia_yes(GtkWidget *liste);
void rechercher_sfax_yes(GtkWidget *liste);
void rechercher_tunis_mahdia_yes(GtkWidget *liste);
void rechercher_tunis_sfax_yes(GtkWidget *liste);
//user find_ag(char id[]);
#endif
