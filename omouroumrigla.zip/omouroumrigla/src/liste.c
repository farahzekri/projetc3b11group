#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include "liste.h"

enum{
CINN,
ID_VOTE,
ID_ELECTION,
ID_LIST,
VOTE_BLANC,
COLUMNS2
};
void ajouter_vote (vote V)
{
FILE *f=fopen("vote.txt","a");
if (f!=NULL)
   {   
   fprintf(f,"%s %s %s %s %s\n",V.cin,V.id_vote,V.id_election,V.id_liste,V.vote_blanc);
   fclose(f);
   }
}
/******************* AJOUTER LISTE ***************************/
void ajouter_liste(liste c){
    FILE *f;
    f=fopen("liste.txt","a");
    if(f!=NULL){
        fprintf(f,"%s %s %s %s %s %s %d %d %d %s %s\n",c.idliste,c.idpresidentliste,c.nompresident,c.prenompresident,c.sexe,c.orinetation,c.jourcliste,c.moiscliste,c.anneecliste,c.programmeelectorale,c.vote);
    }
        fclose(f);
}
/***************************** CONTREOL ID EXIST *********************/ 
int idExist(char id[]){
    liste c;
    FILE *f;
    f = fopen("liste.txt","r");
    if(f != NULL){
    	while(fscanf(f,"%s %s %s %s %s %s %d %d %d %s %s\n",c.idliste,c.idpresidentliste,c.nompresident,c.prenompresident,c.sexe,c.orinetation,&c.jourcliste,&c.moiscliste,&c.anneecliste,c.programmeelectorale,c.vote)!=EOF){
        	if(strcmp(c.idliste,id) == 0){
       		     return 1;
        	}
    	}
}
    fclose(f);
    return 0;
}
/************************** SUPPRIMER LISTE *********************/
void supprimer_liste(char id[]){   
     liste c;
    FILE *f1;
    FILE *f2;

    f1 = fopen("liste.txt","r");
    f2 = fopen("tmp.txt","a");

    while(fscanf(f1,"%s %s %s %s %s %s %d %d %d %s %s\n",c.idliste,c.idpresidentliste,c.nompresident,c.prenompresident,c.sexe,c.orinetation,&c.jourcliste,&c.moiscliste,&c.anneecliste,c.programmeelectorale,c.vote)!=EOF){
        if(strcmp(c.idliste,id)!=0){

                        fprintf(f2,"%s %s %s %s %s %s %d %d %d %s %s\n",c.idliste,c.idpresidentliste,c.nompresident,c.prenompresident,c.sexe,c.orinetation,c.jourcliste,c.moiscliste,c.anneecliste,c.programmeelectorale,c.vote);


        }
    }
    fclose(f1);
    fclose(f2);
    remove("liste.txt");
    rename("tmp.txt","liste.txt");
    
}




/*******************************************************************/


/*********************** FIND LISTE **********************************/
liste find_liste(char id[]){
    liste c;
    FILE *f;
    f = fopen("liste.txt","r");
    if(f != NULL){
    	while(fscanf(f,"%s %s %s %s %s %s %d %d %d %s %s\n",c.idliste,c.idpresidentliste,c.nompresident,c.prenompresident,c.sexe,c.orinetation,&c.jourcliste,&c.moiscliste,&c.anneecliste,c.programmeelectorale,c.vote)!=EOF){
	if(strcmp(c.idliste,id) == 0){
       		return c;    
        }
       		     
       }
}

    fclose(f);
    return ;
} 
/* ************** MODIFIER UNE LISTE *****************/
void modifier_liste(liste p){
    liste c;
    FILE *f;
    FILE *g;
    f = fopen("liste.txt","r");
    g = fopen("tmp.txt","a");
    while(fscanf(f,"%s %s %s %s %s %s %d %d %d %s %s\n",c.idliste,c.idpresidentliste,c.nompresident,c.prenompresident,c.sexe,c.orinetation,&c.jourcliste,&c.moiscliste,&c.anneecliste,c.programmeelectorale,c.vote) != EOF){
         if(strcmp(c.idliste,p.idliste) == 0){
            c = p;
        }
        fprintf(g,"%s %s %s %s %s %s %d %d %d %s %s\n",c.idliste,c.idpresidentliste,c.nompresident,c.prenompresident,c.sexe,c.orinetation,c.jourcliste,c.moiscliste,c.anneecliste,c.programmeelectorale,c.vote);
            
        
        
    }
    fclose(f);
    fclose(g);
    remove("liste.txt");
    rename("tmp.txt","liste.txt");
}
/* ********** AFFICHAGE LISTE ***************/
enum
{
	IDLISTE,
	IDPRESIDENT,
	NOMPRESIDENT,
	PRENOMPRESIDENT,
	SEXEh,
	DATE,
	ORIENTATION,
	PROGRAMME,
	VOTEh,
	COLUMNS1,
};
void afficher_liste(GtkWidget *list)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	char idliste[20];
	char idpresidentliste[20];
	char nompresident[20]; 
	char prenompresident[20];
	char sexe[20];
	char orinetation[20];
	int jourcliste;
	int moiscliste;
	int anneecliste;
	char programmeelectorale[20];
	char vote[200];
	liste c;
	store=NULL;
	FILE *f;
	
	store = gtk_tree_view_get_model(list);

	if(store==NULL){
	renderer=gtk_cell_renderer_text_new();
   	column=gtk_tree_view_column_new_with_attributes("     IdListe     ",renderer,"text",IDLISTE,NULL);
   	gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);


	renderer=gtk_cell_renderer_text_new();
   	column=gtk_tree_view_column_new_with_attributes("     IdPresidentListe     ",renderer,"text",IDPRESIDENT,NULL);
   	gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);


	renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes("     NomPresident     ",renderer,"text",NOMPRESIDENT,NULL);
   	gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);


	renderer=gtk_cell_renderer_text_new();
   	column=gtk_tree_view_column_new_with_attributes("     PrenomPresident     ",renderer,"text",PRENOMPRESIDENT,NULL);
   	gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);


	renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes("        Sexe        ",renderer,"text",SEXEh,NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);


	renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes("             Date d'ajout             ",renderer,"text",DATE,NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);


	renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes("                        Orientation                        ",renderer,"text",ORIENTATION,NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);


	renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes("  ProgrammeElectorale   ",renderer,"text",PROGRAMME,NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);

	renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes(" liste favouriser   ",renderer,"text",VOTEh,NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);
	
	store = gtk_list_store_new(COLUMNS1,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
    
	char text[50];
	f=fopen("liste.txt","r");
 if(f==NULL){return ;}
else    {
	
         while(fscanf(f,"%s %s %s %s %s %s %d %d %d %s %s\n",idliste,idpresidentliste,nompresident,prenompresident,sexe,orinetation,&jourcliste,&moiscliste,&anneecliste,programmeelectorale,vote)!=EOF)
          {
	sprintf(text,"%d/%d/%d",jourcliste,moiscliste,anneecliste);
		
           gtk_list_store_append(store,&iter);
           gtk_list_store_set(store, &iter, IDLISTE, idliste, IDPRESIDENT, idpresidentliste, NOMPRESIDENT, nompresident, PRENOMPRESIDENT, prenompresident, SEXEh, sexe, DATE, text, ORIENTATION, orinetation, PROGRAMME, programmeelectorale, VOTEh, vote, -1);
          
        }
   fclose(f);
   gtk_tree_view_set_model(GTK_TREE_VIEW(list), GTK_TREE_MODEL (store));
   g_object_unref (store);  
   }
}
}
/* ************************* FIN AFFFICHAGE ****************** */


void affichervote(GtkWidget *liste2)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store2;
	char cin[20];
        char id_vote [20];
        char id_election [20];
        char id_liste [20] ;
        char vote_blanc [200];
	store2=NULL;
	FILE *f;
	store2=gtk_tree_view_get_model(liste2);
	if(store2 == NULL)
	{
		renderer = gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("            cin      ",renderer,"text",CIN,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste2),column);

		renderer = gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("       id_vote        ",renderer,"text",ID_VOTE,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste2),column);

		renderer = gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("      id_election       ",renderer,"text",ID_ELECTION,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste2),column);

		renderer = gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("    id_liste      ",renderer,"text",ID_LIST,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste2),column);
		
		renderer = gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("      vote_blanc      ",renderer,"text",VOTE_BLANC,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste2),column);

		





		store2=gtk_list_store_new(COLUMNS2, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING);
		f=fopen("vote.txt","r");
		if(f==NULL)
		{

			return;
		}
		else
		{

			f=fopen("vote.txt","r");
			while(fscanf(f,"%s %s %s %s %s\n",cin,id_vote,id_election,id_liste,vote_blanc)!=EOF)
			{
		          gtk_list_store_append(store2,&iter);
			  gtk_list_store_set(store2,&iter,CIN,cin,ID_VOTE,id_vote,ID_ELECTION,id_election,ID_LIST,id_liste,VOTE_BLANC,vote_blanc, -1);
			}
			fclose(f);
			gtk_tree_view_set_model(GTK_TREE_VIEW(liste2),GTK_TREE_MODEL(store2));
			g_object_unref(store2);
		}
	}
}


/* ************************* RECUPERER L'ORIENTATION ****************** */

int test_orientation(char a[]){
	int i;
        if(strcmp(a,"Gauche")==0)
		i=0;
	else if (strcmp(a,"Droit")==0)
		i=1;
else if (strcmp(a,"Centre")==0)
		i=2;
return i;}

////////////////////////***********************************************************************statyesmine****************************************************
void blanc( float *t){
  int nt =0;
  int ne=0;
  int n=0;

  vote V;
  FILE * g=fopen("vote.txt","r");
  if(g!=NULL){
      while(fscanf(g," %s %s %s %s %s ",V.cin,V.id_vote,V.id_election,V.id_liste,V.vote_blanc)!=EOF){
                if(strcmp(V.vote_blanc,"vote_blanc")==0)
                      nt=nt+1;
                 else
                     ne=ne+1;
                       }
       
       *t=((float)nt/(nt+ne))*100;
      
          }
    fclose(g);


}










