#include <gtk/gtk.h>


void
on_ajouterUser_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_afficher_user_clicked               (GtkButton       *objet,
                                        gpointer         user_data);

void
on_quitajouter_user_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_homme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_femme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
/*
void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

gboolean
on_treeview1_popup_menu                (GtkWidget       *widget,
                                        gpointer         user_data);

gboolean
on_treeview1_button_press_event        (GtkWidget       *widget,
                                        GdkEventButton  *event,
                                        gpointer         user_data);


*/
void
on_ajoutgu_clicked                     (GtkButton       *objet,
                                        gpointer         user_data);

void
on_modifiergu_clicked                  (GtkButton       *objet,
                                        gpointer         user_data);

void
on_supprimergu_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_quitgu_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_recherchegu_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_quit_gestion_des_utilisateur_clicked
                                        (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_modifierUser_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_consultbut_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer_utlisateur_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_femmem_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_hommem_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_confirmer_modif_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_hommep_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_femmep_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_retourU_clicked                     (GtkButton       *objet,
                                        gpointer         user_data);

void
on_retoursuph_clicked                  (GtkButton       *objet,
                                        gpointer         user_data);

void
on_consulter_utilisateur_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonloginconfirm_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_checkbuttonpasslogin_toggled        (GtkWidget        *objet,
                                        gpointer         user_data);

void
on_guacceuil_clicked                   (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_consultation_clicked                (GtkButton       *objet,
                                        gpointer         user_data);

void
on_buttonlogadmin_clicked              (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_exitsupprimer_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_exitmodif_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_exitwindowlogin_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_deconnecter_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_exitacceuil_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_retourwindolwogin_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_calculeAgemoy_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_calculeNbr_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_statAcceuil_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonajyesmine2_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficherbr_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkassure_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkverif_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2yes_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1yes_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttondefaut_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_retouryesmine_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonajyesmine_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonmodyesmine_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonsuppyesmine_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonactualiserbr_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonrechercheyesmine_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_gbvAcceuil_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonmodyesmine2_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobuttonhommebr_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonfemmebr_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkverif2_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkassure2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_retouryesmine2_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonsuppbr_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_retouryesmine3_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_retouryesmine4_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_confirmer_ajouter_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_return_de_ajouter_gest_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobuttonvill3_ajou_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonvill2_ajou_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonvill1_ajou_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_rechercher_election_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajouter_election_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifier_election_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer_election_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_return_de_supp_gest_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_confirmer_supprimer_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_return_de_modi_gest_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_confirmer_modifier_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobuttonvill1_modi_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonvill3_modi_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonvill2_modi_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_retour_stat_clicked                 (GtkButton       *objet,
                                        gpointer         user_data);

void
on_quit_gu_stat_clicked                (GtkButton       *objet,
                                        gpointer         user_data);

void
on_geAcceuil_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retourf_acc_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ge_stat_clicked                     (GtkButton       *objet,
                                        gpointer         user_data);

void
on_ajouter_ob_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_journaliste_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_observateur_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_hote_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_interprete_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_hommeo_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_femmeo_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_g_ob_acceuil_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_g_ob_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_aj_gob_clicked                      (GtkButton       *objet,
                                        gpointer         user_data);

void
on_actualiser_ob_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_recherche_multi_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkprofession_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checknationalite_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkgenre_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);



void
on_retour_aj_gob1_clicked              (GtkButton       *objet,
                                        gpointer         user_data);

void
on_buttonagentyes_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonconsulterbr_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_cheryesmine_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkvilleyesmine1_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkvilleyesmine2_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkvilleyesmine3_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_supp_obs_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_supgob_clicked                      (GtkButton       *objet,
                                        gpointer         user_data);

void
on_retour_obv_supp_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonajouterliste_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_backaddliste_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobuttonhommeliste_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonfemmeliste_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttongotoaddliste_clicked          (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_buttongotomodifliste_clicked        (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_buttongotosupprimerliste_clicked    (GtkWidget     *objet,
                                        gpointer         user_data);
/**********************************************************************************/
void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

gboolean
on_treeview1_popup_menu                (GtkWidget *treeview, gpointer userdata);

gboolean
on_treeview1_button_press_event        (GtkWidget *treeview, GdkEventButton *event, gpointer userdata);

void
on_radiobuttonhommem_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonfemmem_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonconsulterliste_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_backmodifliste_clicked              (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_modifierliste_clicked               (GtkWidget     *objet,
                                        gpointer         user_data);

void
on_buttonsupprimerliste_clicked        (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_buttonbacksuppliste_clicked         (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_radiobuttonvb_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);



void
on_backvote_clicked                    (GtkWidget        *objet,
                                        gpointer         user_data);

void
on_buttonobset_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonobstn_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_Actualise_tree_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton_rech1_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_rech2_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_rech3_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_valide_rech_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_valider_tache_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonconfirmervote_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_espace_admin_clicked                (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_espace_electeur_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajoutvotehs1_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_liste_elecths_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_espace_agent_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_backliste1_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_quit_vote7_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_vote4_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttontauxvoteblanc_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifier_observateur1_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifobs9_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_backacceuil2_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_modifobs1_clicked            (GtkButton       *button,
                                        gpointer         user_data);
