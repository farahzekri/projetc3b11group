#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "users.h"
#include <gtk/gtk.h>
/***************************************generer motdepasse*/////////////////////
void genererPassword(char password[])
{
	char str[20];

	int size=20;
	srand(time(NULL) * size );
	int n;
    const char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJK";
    if (size) {
        --size;
        for ( n = 0; n < size; n++) {
            int key = rand() % (int) (sizeof charset - 1);
            str[n] = charset[key];
        }
        str[size] = '\0';
    }
	
strcpy(password,str);
}
/*******************************************ajouter utilisateur*///////////////////
void ajouter_user(user u)
{
FILE *f=NULL;
f=fopen("utilisateur.txt","a");
if(f!=NULL)
{
fprintf(f, "%s %s %s %s %d/%d/%d %s %s %s %s %s %s\n",u.cin,u.nom,u.prenom,u.id_bureau,u.dateN.jour,u.dateN.mois,u.dateN.annee,u.email,u.tel,u.role,u.sexe,u.vote,u.password);
fclose(f);
}
}

//****************************************************supprimer user*/
void supprimer_user(char id[])
{
	user u;
    FILE *f1;
    FILE *f2;

    f1 = fopen("utilisateur.txt","r");
    f2 = fopen("tmp.txt","a");

    while(fscanf(f1,"%s %s %s %s %d/%d/%d %s %s %s %s %s %s\n",u.cin,u.nom,u.prenom,u.id_bureau,&u.dateN.jour,&u.dateN.mois,&u.dateN.annee,u.email,u.tel,u.role,u.sexe,u.vote,u.password) != EOF){
        if(strcmp(u.cin,id)!=0){

                        fprintf(f2, "%s %s %s %s %d/%d/%d %s %s %s %s %s %s\n",u.cin,u.nom,u.prenom,u.id_bureau,u.dateN.jour,u.dateN.mois,u.dateN.annee,u.email,u.tel,u.role,u.sexe,u.vote,u.password);


        }
    }
    fclose(f1);
    fclose(f2);
    remove("utilisateur.txt");
    rename("tmp.txt","utilisateur.txt");

}
//*******************************************************modifier user

void modifier_user(user u1){
     user u;
    FILE *f;
    FILE *g;
    f = fopen("utilisateur.txt","r");
    g = fopen("tmp.txt","a");
     while(fscanf(f,"%s %s %s %s %d/%d/%d %s %s %s %s %s %s\n",u.cin,u.nom,u.prenom,u.id_bureau,&u.dateN.jour,&u.dateN.mois,&u.dateN.annee,u.email,u.tel,u.role,u.sexe,u.vote,u.password) != EOF)
{

        if(strcmp(u.cin,u1.cin) == 0){
            u = u1;
        }
        fprintf(g, "%s %s %s %s %d/%d/%d %s %s %s %s %s %s\n",u.cin,u.nom,u.prenom,u.id_bureau,u.dateN.jour,u.dateN.mois,u.dateN.annee,u.email,u.tel,u.role,u.sexe,u.vote,u.password);

    }
    fclose(f);
    fclose(g);
    remove("utilisateur.txt");
    rename("tmp.txt","utilisateur.txt");

}
/******************update user*//////////////////////////////
user update_user(char id[])
{
	user u;
        user um;
        FILE *f1;
    f1 = fopen("utilisateur.txt","r");
    while(fscanf(f1,"%s %s %s %s %d/%d/%d %s %s %s %s %s %s\n",u.cin,u.nom,u.prenom,u.id_bureau,&u.dateN.jour,&u.dateN.mois,&u.dateN.annee,u.email,u.tel,u.role,u.sexe,u.vote,u.password) != EOF){
        if(strcmp(u.cin,id)==0){

     um=u;
        }
    }
    fclose(f1);
    return um;
}
//********************************************************verification cin
int verifier_CIN(char cin[]){
     user u;
 FILE *f1;
    f1 = fopen("utilisateur.txt","r");
    while(fscanf(f1,"%s %s %s %s %d/%d/%d %s %s %s %s %s %s\n",u.cin,u.nom,u.prenom,u.id_bureau,&u.dateN.jour,&u.dateN.mois,&u.dateN.annee,u.email,u.tel,u.role,u.sexe,u.vote,u.password) != EOF){
        if(strcmp(u.cin,cin)==0){	                 
	return 1;
        }
    }
    fclose(f1);
	return 0;
}


//***********************************************************recherche hsan

user find_user(char id[]){
    user u;
    FILE *f;
    f = fopen("utilisateur.txt","r");
    if(f != NULL){
	while(fscanf(f,"%s %s %s %s %d/%d/%d %s %s %s %s %s %s\n",u.cin,u.nom,u.prenom,u.id_bureau,&u.dateN.jour,&u.dateN.mois,&u.dateN.annee,u.email,u.tel,u.role,u.sexe,u.vote,u.password) != EOF)
        {
		if(strcmp(u.cin,id) == 0)
	        {
       			return u;
                }
       }
     }
   
    fclose(f);
} 

//*************************************************************verification de role 
int test_role(char role[]){
	int i;
        if(strcmp(role,"electeur")==0)
		i=0;
	else if (strcmp(role,"AGENT-de-bureau")==0)
		i=1;
        else if (strcmp(role,"observateur")==0)
		i=2;
        if(strcmp(role,"ADMIN")==0)
		i=4;
	return i;
}


///////////////////////**************************************************affichage
enum
{

NOM,
PRENOM,
CIN,
EMAIL,
SEXE,
DATEN,
TEL,
ID_bureau,
ROLE,
VOTE,
COLUMNS
};

void afficher_user(GtkWidget *liste)
{
	
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	char nom[20];
	char prenom[20];
	char cin[20];
	char email[30];
	char sexe[20];
	char dateN[20];
	char tel[20];
	char id_bureau[20];
	char role[20];
	char vote[20];
	char password[20];
	store=NULL;
	FILE *f;
	store=gtk_tree_view_get_model(liste);
	if(store == NULL)
	{
		

		renderer = gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("   Cin   ",renderer,"text",CIN,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

		renderer = gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("        NOM           ",renderer,"text",NOM,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		
		renderer = gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("            prenom            ",renderer,"text",PRENOM,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		
		renderer = gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("        id de bureau       ",renderer,"text",ID_bureau,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		
		renderer = gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("                   Date de naissance               ",renderer,"text",DATEN,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		
		renderer = gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("         email           ",renderer,"text",EMAIL,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		
		renderer = gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("            nulméro de téléphone            ",renderer,"text",TEL,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		
		renderer = gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("           Role            ",renderer,"text",ROLE,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		renderer = gtk_cell_renderer_text_new();

		column=gtk_tree_view_column_new_with_attributes("        sexe       ",renderer,"text",SEXE,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

		renderer = gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("            vote            ",renderer,"text",VOTE,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

		store=gtk_list_store_new(COLUMNS, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
		f=fopen("utilisateur.txt","r");
		if(f==NULL)
		{

			return;
		}
		else
		{

			f=fopen("utilisateur.txt","r");
			while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s\n",cin,nom,prenom,id_bureau,dateN,email,tel,role,sexe,vote,password)!=EOF)
			{
				gtk_list_store_append(store,&iter);
				gtk_list_store_set(store, &iter, CIN, cin, NOM, nom, PRENOM, prenom, ID_bureau, id_bureau, DATEN, dateN, EMAIL, email, TEL, tel, ROLE, role, SEXE, sexe, VOTE, vote, -1);
			}
			fclose(f);
			gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
			g_object_unref(store);
		}
	}
}

///*****************************************************************************login
int  login(char id[],char mdp[]){
   user u;
 FILE *f1;
    f1 = fopen("utilisateur.txt","r");
    while(fscanf(f1,"%s %s %s %s %d/%d/%d %s %s %s %s %s %s\n",u.cin,u.nom,u.prenom,u.id_bureau,&u.dateN.jour,&u.dateN.mois,&u.dateN.annee,u.email,u.tel,u.role,u.sexe,u.vote,u.password) != EOF){
        if(strcmp(u.cin,id)==0&&strcmp(u.password,mdp)==0){
            return 1;           
        }
    }

    fclose(f1);
return 0;
}
/////////////////////////////////////////////////////////*************************************recherche multicritare
void rechercher_user(GtkWidget *liste,char rech[])
{
	
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	char nom[20];
	char prenom[20];
	char cin[20];
	char email[30];
	char sexe[20];
	char dateN[20];
	char tel[20];
	char id_bureau[20];
	char role[20];
	char vote[20];
	char password[30];
	store=NULL;
	FILE *f;
	store=gtk_tree_view_get_model(liste);
	if(store == NULL)
	{
		

		renderer = gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("   Cin   ",renderer,"text",CIN,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

		renderer = gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("        NOM           ",renderer,"text",NOM,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		
		renderer = gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("            prenom            ",renderer,"text",PRENOM,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		
		renderer = gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("        id de bureau       ",renderer,"text",ID_bureau,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		
		renderer = gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("                   Date de naissance               ",renderer,"text",DATEN,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		
		renderer = gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("         email           ",renderer,"text",EMAIL,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		
		renderer = gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("            numéro de téléphone            ",renderer,"text",TEL,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		
		renderer = gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("           Role            ",renderer,"text",ROLE,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		renderer = gtk_cell_renderer_text_new();

		column=gtk_tree_view_column_new_with_attributes("        sexe       ",renderer,"text",SEXE,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

		renderer = gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("            vote            ",renderer,"text",VOTE,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

		store=gtk_list_store_new(COLUMNS, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
		f=fopen("utilisateur.txt","r");
		if(f==NULL)
		{

			return;
		}
		else
		{

			f=fopen("utilisateur.txt","r");
			while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s\n",cin,nom,prenom,id_bureau,dateN,email,tel,role,sexe,vote,password)!=EOF)
			{
				if(strcmp(rech,cin)==0 ||strcmp(rech,id_bureau)==0||strcmp(rech,tel)==0 ){
				gtk_list_store_append(store,&iter);
				gtk_list_store_set(store, &iter, CIN, cin, NOM, nom, PRENOM, prenom, ID_bureau, id_bureau, DATEN, dateN, EMAIL, email, TEL, tel, ROLE, role, SEXE, sexe, VOTE, vote, -1);
			}}
			fclose(f);
			gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
			g_object_unref(store);
		}
	}
}
//***********************************************************************************statistique calcule age moyenne
float ageMoy(int year)
{
    user u;
    FILE *f;
    float moy=0;
    int i=0,age=0;
    f = fopen("utilisateur.txt","r");
    if(f != NULL){
    	while(fscanf(f,"%s %s %s %s %d/%d/%d %s %s %s %s\n",u.cin,u.nom,u.prenom,u.id_bureau,&u.dateN.jour,&u.dateN.mois,&u.dateN.annee,u.email,u.tel,u.role,u.sexe) != EOF){
        	//if(strcmp(u.role,"electeur")==0){
       		     i=i+1;
		     age=age+(year-u.dateN.annee);
        	//}
		
    	}
}
    fclose(f);
    moy=age/i;
    return moy;
}
//***************************************************************************************statistique calcule nombre de bureau
int nbrBureau(char id[]){ 
	int nbr=0;
        user u;
	FILE *f1;	
     f1=fopen("utilisateur.txt", "r");
    if(f1!=NULL)
    {
        while(fscanf(f1,"%s %s %s %s %d/%d/%d %s %s %s %s\n",u.cin,u.nom,u.prenom,u.id_bureau,&u.dateN.jour,&u.dateN.mois,&u.dateN.annee,u.email,u.tel,u.role,u.sexe) != EOF)
        {
           
               if(strcmp(u.id_bureau,id) == 0){ 
                 nbr = nbr+1 ;
                    }
		}
	 }
    fclose(f1);

return nbr;

}

/////////////////////////////////////////////////////////////findagentdeyesmine/////////////////////////////////////////////////////////////////////////////

user find_ag(char id[]){
    
    user u;
    FILE *f,*f1;
    f = fopen("bureau.txt","r");
    f1=fopen("utilisateur.txt","r");
    if(f != NULL){
	while(fscanf(f1,"%s %s %s %s %d/%d/%d %s %s %s %s %s %s\n",u.cin,u.nom,u.prenom,u.id_bureau,&u.dateN.jour,&u.dateN.mois,&u.dateN.annee,u.email,u.tel,u.role,u.sexe,u.vote,u.password) != EOF)
        {

             
		if(strcmp(id,u.id_bureau) == 0)
	        {
       			return u;}
           
       }
     }
   
    fclose(f);
    fclose(f1);
} 
////////////////////////////////////////////////////////////////////////////////////////////////////////////statfarah/////////////////////////////////////////////////////////////////////////////////




float TPE(char *filename)
{
   int nb_electeur_vote=0;
   int nb_electeur=0;
   float tauxpele;
   user u;
   FILE *f1=fopen("utilisateur.txt","r");
   if(f1!=NULL)
   {
    while(fscanf(f1,"%s %s %s %s %d/%d/%d %s %s %s %s %s %s\n",u.cin,u.nom,u.prenom,u.id_bureau,&u.dateN.jour,&u.dateN.mois,&u.dateN.annee,u.email,u.tel,u.role,u.sexe,u.vote,u.password) != EOF)
    {
          if((strcmp(u.role,"electeur"))==0)
          {
            nb_electeur=nb_electeur+1;
             if((strcmp(u.vote,"🆕"))!=0)
              {
                nb_electeur_vote=nb_electeur_vote+1;
              }
          }

    }

   
   }
   tauxpele= (float)nb_electeur_vote/nb_electeur;
  fclose(f1);
return tauxpele;
}
void TPHF(float *f, float *h)
{
     
    int nf=0;
    int nh =0;
    int nb_vote=0;
   
    user u;

    FILE *f1=fopen("utilisateur.txt", "r");
    if(f1!=NULL)
    {
        while(fscanf(f1,"%s %s %s %s %d/%d/%d %s %s %s %s %s %s\n",u.cin,u.nom,u.prenom,u.id_bureau,&u.dateN.jour,&u.dateN.mois,&u.dateN.annee,u.email,u.tel,u.role,u.sexe,u.vote,u.password) != EOF)
        {
          if((strcmp(u.role,"electeur"))==0 && (strcmp(u.vote,"🆕"))!=0)
          {
             nb_vote=nb_vote+1;
              if((strcmp(u.sexe,"homme"))==0)
               {
               
                nh=nh+1;
               }
             
              else if ((strcmp(u.sexe,"femme"))==0) 
              {
             
               nf=nf+1;
              }
          }
             
        }
     
      *f=(float)nf/nb_vote;
      *h=(float)nh/nb_vote;
      
      
    }
    fclose(f1);
}



