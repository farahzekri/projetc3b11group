#include <gtk/gtk.h>
#ifndef ELECTION_H_INCLUDED
#define ELECTION_H_INCLUDED
#include <stdio.h>
typedef struct
{
    int jour;
    int mois;
    int annee;
}Date;

typedef struct
{
    char id[10];
    Date date_election;
    char ville[20];
    char municipalite[50];
    char nb_habitant[50];
    char nb_conseille[50];
    
    
}GestionElection;

void ajouter_elections(GestionElection E);
void afficher_elections(GtkWidget *liste);
void supprimer_elections(char idele[]);
void modifier_elections(GestionElection E1);
void rechercher_elections(GtkWidget *liste,char rechele[]);
void rechercher_mahdia(GtkWidget *liste);
void rechercher_tunis(GtkWidget *liste);
void rechercher_sfax(GtkWidget *liste);
int control_id(char id[]);

#endif
