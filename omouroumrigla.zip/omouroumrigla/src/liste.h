
#include<gtk/gtk.h>
typedef struct
{
char idliste[20];
char idpresidentliste[20]; 
char nompresident[20];
char prenompresident[20];
char sexe[20];
char orinetation[20];
char programmeelectorale[200];
char vote[20];
int jourcliste;
int moiscliste;
int anneecliste;
}liste;


typedef struct {
char cin[20];
char id_vote [20];
char id_election [20];
char id_liste [20] ;
char vote_blanc [20];
}vote;


void ajouter_vote (vote V);
void affichervote(GtkWidget *liste2);
void ajouter_liste(liste c);
int idExist(char id[]);
void supprimer_liste(char id[]);
liste find_liste(char id[]);
void modifier_liste(liste c);
void afficher_listes(GtkWidget *list);

void blanc( float *t);



